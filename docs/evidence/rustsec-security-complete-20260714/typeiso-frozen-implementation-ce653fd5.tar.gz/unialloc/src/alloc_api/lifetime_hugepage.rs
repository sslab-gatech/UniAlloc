//! Feature-gated payload arenas driven by exact lifetime metadata or runtime
//! allocation-site survival.
//!
//! Classified objects carry one of the stable ABI values Unknown/Ephemeral/
//! LongLived. A process-wide logical epoch records whether each routed object
//! dies within its allocation phase or survives a phase boundary, producing
//! object- and rounded-slot-byte-weighted predictor and placement confusion
//! matrices. Regions reused across epochs by a non-cohort policy are excluded
//! when individual object epochs cannot be recovered without side metadata. The
//! epoch-cohort policy also keeps different birth epochs out of the same 2 MiB
//! extent. The adaptive policy learns site survival from later allocation
//! pressure and uses static lifetime metadata only as a weak prior.
//!
//! The implementation deliberately owns all bookkeeping in fixed process
//! tables. Mapping or releasing an extent therefore cannot recurse through the
//! allocator whose payload path it is implementing.

use super::type_isolation::{
    lifetime_placement_class, AllocationMetadata, LifetimePlacementClass, FLAG_DELAYED_FREE,
};
use crate::pal::sys_alloc::{self, prots, HugePageMmapBacking};
use crate::size_class::{get_size_class_tuple, SizeClass, TOTAL_SIZE_CLASS};
use core::alloc::Layout;
use core::mem::size_of;
use core::sync::atomic::{AtomicUsize, Ordering};
use spin::Mutex;

pub const LIFETIME_HUGEPAGE_EXTENT_BYTES: usize = 2 * 1024 * 1024;
pub const LIFETIME_HUGEPAGE_IDENTITY_REGION_BYTES: usize = 64 * 1024;

// The configured research host owns 4,096 persistent 2 MiB pages (8 GiB).
// Keep the descriptor bound explicit so allocator metadata cannot recursively
// grow with the payload working set.
const MAX_EXTENTS: usize = 4096;
const EXTENT_LOOKUP_SLOTS: usize = MAX_EXTENTS * 2;
const EXTENT_LOOKUP_MASK: usize = EXTENT_LOOKUP_SLOTS - 1;
const MAX_SLOT_ALIGN: usize = 32 * 1024;
const MAX_SLOT_BYTES: usize = 64 * 1024;
const IDENTITY_REGIONS_PER_EXTENT: usize =
    LIFETIME_HUGEPAGE_EXTENT_BYTES / LIFETIME_HUGEPAGE_IDENTITY_REGION_BYTES;
const ALIGN_CLASS_COUNT: usize = 16;
const LIFETIME_CLASS_COUNT: usize = 2;
const BUCKET_COUNT: usize = LIFETIME_CLASS_COUNT * TOTAL_SIZE_CLASS * ALIGN_CLASS_COUNT;
const NONE: usize = usize::MAX;
const TOMBSTONE: usize = usize::MAX - 1;
// Preregistered feasibility threshold for the first runtime-validation
// experiment. It is an evaluation parameter, not a claimed universal optimum.
const THP_PROMOTION_MIN_LIVE_BYTES: usize = LIFETIME_HUGEPAGE_EXTENT_BYTES / 2;

// Marker-free lifetime learning uses allocation pressure instead of attempting
// to infer application-specific semantic phases. One epoch is one 2 MiB THP's
// worth of eligible exact-site payload capacity. Both tracked allocations and
// model-directed base-allocator bypasses advance pressure. Objects released
// before 2 MiB of later pressure are short, objects surviving at least 8 MiB
// are long, and the interval between those thresholds is deliberately censored.
const ADAPTIVE_EPOCH_BYTES: u64 = LIFETIME_HUGEPAGE_EXTENT_BYTES as u64;
const ADAPTIVE_LONG_AGE_BYTES: u64 = 4 * ADAPTIVE_EPOCH_BYTES;
const ADAPTIVE_SITE_SLOTS: usize = 4096;
const ADAPTIVE_SITE_PROBE_LIMIT: usize = 16;
const ADAPTIVE_MIN_DECISIVE_SAMPLES: u32 = 8;
const ADAPTIVE_MIN_SAMPLES_AFTER_TRANSITION: u32 = 4;
const ADAPTIVE_COUNTER_DECAY_INTERVAL: u32 = 256;
const ADAPTIVE_COLD_MAX_INFLIGHT: u32 = 8;
const ADAPTIVE_SHORT_SAMPLE_INTERVAL: u32 = 256;
const ADAPTIVE_TRAILER_ACTIVE: u16 = 1;

#[inline]
fn adaptive_lifetime_outcome(age_bytes: u64) -> Option<bool> {
    if age_bytes < ADAPTIVE_EPOCH_BYTES {
        Some(false)
    } else if age_bytes >= ADAPTIVE_LONG_AGE_BYTES {
        Some(true)
    } else {
        None
    }
}

/// Physical page backend used for placements selected by the lifetime policy.
///
/// Placement policy and backing mechanism are configured independently so the
/// same lifetime experiment can compare explicit HugeTLB against Linux THP.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
#[repr(u8)]
pub enum LifetimePageBackend {
    ExplicitHugeTLB = 0,
    TransparentHugepage = 1,
}

impl LifetimePageBackend {
    #[inline]
    fn from_usize(value: usize) -> Self {
        match value {
            1 => Self::TransparentHugepage,
            _ => Self::ExplicitHugeTLB,
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
#[repr(u8)]
pub enum LifetimeHugepagePolicy {
    Disabled = 0,
    SegregatedOrdinary = 1,
    LongLivedHugepage = 2,
    SegregatedHugepage = 3,
    /// Apply the binary lifetime policy while keeping allocations from
    /// different runtime epochs out of the same 2 MiB extent. Static
    /// confidence abstention happens before this ABI and arrives as Unknown.
    EpochCohortHugepage = 4,
    /// Learn allocation-site survival from allocator-observed byte pressure.
    /// Tracked Cold and sampled Short allocations use ordinary
    /// `MADV_NOHUGEPAGE` extents, model-directed bypasses use the base allocator,
    /// and learned-Long sites use eager anonymous `MADV_HUGEPAGE` extents.
    AdaptiveRuntimeHugepage = 5,
}

impl LifetimeHugepagePolicy {
    #[inline]
    fn from_usize(value: usize) -> Self {
        match value {
            1 => Self::SegregatedOrdinary,
            2 => Self::LongLivedHugepage,
            3 => Self::SegregatedHugepage,
            4 => Self::EpochCohortHugepage,
            5 => Self::AdaptiveRuntimeHugepage,
            _ => Self::Disabled,
        }
    }

    #[inline]
    fn requested_backing(
        self,
        class: LifetimePlacementClass,
        backend: LifetimePageBackend,
    ) -> Option<RequestedBacking> {
        let requested = match (self, class) {
            (Self::Disabled, _) | (_, LifetimePlacementClass::Unknown) => None,
            (Self::SegregatedOrdinary, _) => Some(RequestedBacking::Ordinary),
            (
                Self::LongLivedHugepage | Self::EpochCohortHugepage | Self::AdaptiveRuntimeHugepage,
                LifetimePlacementClass::Ephemeral,
            ) => Some(RequestedBacking::Ordinary),
            (
                Self::LongLivedHugepage | Self::EpochCohortHugepage | Self::AdaptiveRuntimeHugepage,
                LifetimePlacementClass::LongLived,
            )
            | (Self::SegregatedHugepage, _) => Some(RequestedBacking::LargePage),
        };
        if backend == LifetimePageBackend::TransparentHugepage
            && self == Self::EpochCohortHugepage
            && requested == Some(RequestedBacking::LargePage)
        {
            Some(RequestedBacking::EpochCandidate)
        } else {
            requested
        }
    }

    #[inline]
    fn separates_epoch_extents(self) -> bool {
        self == Self::EpochCohortHugepage
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
#[repr(u8)]
enum RequestedBacking {
    Ordinary = 1,
    LargePage = 2,
    EpochCandidate = 3,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
#[repr(u8)]
enum ActualBacking {
    Unmapped = 0,
    Ordinary = 1,
    Hugetlb = 2,
    HugetlbFallback = 3,
    /// `MADV_HUGEPAGE` failed; the aligned anonymous mapping remains usable.
    ThpAdviceFailed = 4,
    /// The VMA accepted `MADV_HUGEPAGE`; actual THP backing is unverified.
    ThpAdvisedUnverified = 5,
    /// Delayed candidate held under `MADV_NOHUGEPAGE` until runtime validation.
    ThpCandidateNoHugepage = 6,
    /// Delayed candidate whose initial `MADV_NOHUGEPAGE` failed. Its actual
    /// page size remains unverified until the promotion transition runs.
    ThpCandidateNoHugepageAdviceFailed = 7,
    /// `MADV_COLLAPSE` succeeded for this range at a phase boundary. Linux may
    /// split the THP later, so this is a point-in-time observation.
    ThpCollapseSucceededPointInTime = 8,
}

impl ActualBacking {
    #[inline]
    fn is_hugetlb(self) -> bool {
        self == Self::Hugetlb
    }

    #[inline]
    fn is_thp_mapping(self) -> bool {
        matches!(
            self,
            Self::ThpAdviceFailed
                | Self::ThpAdvisedUnverified
                | Self::ThpCandidateNoHugepage
                | Self::ThpCandidateNoHugepageAdviceFailed
                | Self::ThpCollapseSucceededPointInTime
        )
    }

    #[inline]
    fn is_thp_confirmed_at_collapse(self) -> bool {
        self == Self::ThpCollapseSucceededPointInTime
    }

    #[inline]
    fn is_large_page_confirmed(self) -> bool {
        self.is_hugetlb() || self.is_thp_confirmed_at_collapse()
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum ThpAdviceOutcome {
    NotAttempted,
    Succeeded,
    Failed,
}

#[derive(Clone, Copy)]
struct ExtentMapping {
    base: *mut u8,
    backing: ActualBacking,
    nohugepage_advice_ok: bool,
    thp_advice: ThpAdviceOutcome,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum ThpPromotionEligibility {
    Ineligible,
    LowOccupancy,
    Eligible,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
#[repr(C)]
pub struct LifetimeHugepageStatsSnapshot {
    pub policy: LifetimeHugepagePolicy,
    pub backend: LifetimePageBackend,
    pub extent_bytes: usize,
    /// Current process-wide allocation epoch. Epoch 1 is the initial phase.
    pub current_epoch: usize,
    pub phase_advances: usize,
    pub epoch_cohort_extent_mappings: usize,
    pub routed_allocations: usize,
    pub routed_deallocations: usize,
    pub unknown_bypasses: usize,
    pub unknown_bypass_requested_bytes: usize,
    pub unsupported_layout_bypasses: usize,
    pub allocation_fallbacks: usize,
    pub slot_reuse_hits: usize,
    pub slot_bump_allocations: usize,
    pub identity_region_assignments: usize,
    pub identity_region_releases: usize,
    pub ordinary_extent_mappings: usize,
    pub hugetlb_extent_mappings: usize,
    pub hugetlb_fallback_extent_mappings: usize,
    /// Anonymous aligned mappings owned by the THP backend. This counts VMAs,
    /// not confirmed PMD mappings.
    pub thp_extent_mappings: usize,
    /// THP mappings initially held under `MADV_NOHUGEPAGE` for epoch survival
    /// and occupancy validation.
    pub thp_candidate_extent_mappings: usize,
    pub thp_advice_attempts: usize,
    pub thp_advice_successes: usize,
    pub thp_advice_errors: usize,
    /// Surviving candidate observations that met the 50% live-slot threshold.
    pub thp_collapse_eligible_extents: usize,
    pub thp_collapse_low_occupancy_skips: usize,
    pub thp_collapse_attempts: usize,
    /// Point-in-time successful `MADV_COLLAPSE` operations. Later splitting is
    /// possible and requires external smaps/perf validation for steady state.
    pub thp_collapse_successes: usize,
    pub thp_collapse_errors: usize,
    /// Most recent Linux errno returned by `MADV_COLLAPSE`, or zero when no
    /// collapse failure has been observed since the last statistics reset.
    pub thp_collapse_last_error_code: isize,
    pub mapping_failures: usize,
    pub nohugepage_advice_failures: usize,
    pub extent_unmaps: usize,
    pub extent_unmap_failures: usize,
    pub current_extents: usize,
    pub peak_extents: usize,
    pub current_ordinary_extents: usize,
    pub peak_ordinary_extents: usize,
    pub current_hugetlb_extents: usize,
    pub peak_hugetlb_extents: usize,
    pub current_thp_extents: usize,
    pub peak_thp_extents: usize,
    pub current_thp_collapse_confirmed_extents: usize,
    pub peak_thp_collapse_confirmed_extents: usize,
    pub live_objects: usize,
    pub live_ephemeral_objects: usize,
    pub live_long_lived_objects: usize,
    pub live_slot_bytes: usize,
    /// Allocation generations whose allocate/release epochs produced runtime
    /// truth. A moved realloc closes the old generation and starts a new one;
    /// an in-place realloc preserves its original birth epoch.
    pub runtime_validated_objects: usize,
    pub runtime_validated_bytes: usize,
    /// Objects excluded because delayed release or a mixed-epoch region
    /// obscures the individual object's logical death epoch.
    pub runtime_validation_excluded_objects: usize,
    pub runtime_validation_excluded_bytes: usize,
    pub runtime_delayed_free_excluded_objects: usize,
    pub runtime_delayed_free_excluded_bytes: usize,
    pub runtime_mixed_epoch_excluded_objects: usize,
    pub runtime_mixed_epoch_excluded_bytes: usize,
    /// Predictor confusion matrix. "Positive" means predicted long-lived;
    /// byte fields measure rounded arena slot bytes.
    pub predictor_true_positive_objects: usize,
    pub predictor_true_positive_bytes: usize,
    pub predictor_true_negative_objects: usize,
    pub predictor_true_negative_bytes: usize,
    pub predictor_false_positive_objects: usize,
    pub predictor_false_positive_bytes: usize,
    pub predictor_false_negative_objects: usize,
    pub predictor_false_negative_bytes: usize,
    /// Actual-placement confusion matrix. "Positive" means explicit HugeTLB
    /// or a point-in-time successful THP collapse; advice-only THP remains
    /// unverified. Byte fields measure rounded arena slot bytes.
    pub placement_true_positive_objects: usize,
    pub placement_true_positive_bytes: usize,
    pub placement_true_negative_objects: usize,
    pub placement_true_negative_bytes: usize,
    pub placement_false_positive_objects: usize,
    pub placement_false_positive_bytes: usize,
    pub placement_false_negative_objects: usize,
    pub placement_false_negative_bytes: usize,
    pub current_identity_regions: usize,
    pub peak_identity_regions: usize,
    pub retained_bytes: usize,
    /// Bytes held in completely unassigned regions that can serve the current
    /// policy and allocation epoch immediately.
    pub reusable_unassigned_region_bytes: usize,
    /// Unassigned bytes pinned in older epoch-cohort extents. They cannot be
    /// reused by a later cohort while any slot in the extent remains live.
    pub cohort_pinned_unassigned_region_bytes: usize,
    /// Bytes inside assigned regions that are not occupied by live slots.
    pub assigned_region_slack_bytes: usize,
    /// Total retained payload capacity beyond the current live rounded slots.
    pub retained_slack_bytes: usize,
    /// Compatibility alias for `retained_slack_bytes`.
    pub stranded_bytes: usize,
    pub all_mappings_released: bool,
    /// Marker-free classifier input and model telemetry. Pressure counts
    /// eligible exact-site payload capacity for tracked allocations and
    /// model-directed bypasses; slot trailers are excluded.
    pub adaptive_pressure_bytes: u64,
    pub adaptive_pressure_epoch: usize,
    pub adaptive_epoch_advances: usize,
    pub adaptive_site_count: usize,
    pub adaptive_cold_sites: usize,
    pub adaptive_short_sites: usize,
    pub adaptive_long_sites: usize,
    pub adaptive_eligible_allocations: usize,
    pub adaptive_training_allocations: usize,
    pub adaptive_cold_bypassed_allocations: usize,
    pub adaptive_short_routed_allocations: usize,
    pub adaptive_short_bypassed_allocations: usize,
    pub adaptive_long_routed_allocations: usize,
    pub adaptive_missing_identity_bypasses: usize,
    pub adaptive_site_table_bypasses: usize,
    pub adaptive_prior_conflicts: usize,
    pub adaptive_live_trailers: usize,
    pub adaptive_trailer_corruptions: usize,
    pub adaptive_short_observations: usize,
    pub adaptive_long_observations: usize,
    pub adaptive_censored_observations: usize,
    pub adaptive_decisive_observation_bytes: usize,
    pub adaptive_promotions: usize,
    pub adaptive_demotions: usize,
    pub adaptive_prior_corrections: usize,
    /// Prequential learned-prediction matrix. Cold abstentions are excluded;
    /// byte fields use payload capacity and exclude the hidden trailer.
    pub adaptive_predictor_true_positive_objects: usize,
    pub adaptive_predictor_true_positive_bytes: usize,
    pub adaptive_predictor_true_negative_objects: usize,
    pub adaptive_predictor_true_negative_bytes: usize,
    pub adaptive_predictor_false_positive_objects: usize,
    pub adaptive_predictor_false_positive_bytes: usize,
    pub adaptive_predictor_false_negative_objects: usize,
    pub adaptive_predictor_false_negative_bytes: usize,
    /// Allocation-time compiler/static-hint matrix against allocator pressure
    /// truth. Unknown hints are counted separately as abstentions; byte fields
    /// use payload capacity and exclude the hidden trailer.
    pub adaptive_static_hint_true_positive_objects: usize,
    pub adaptive_static_hint_true_positive_bytes: usize,
    pub adaptive_static_hint_true_negative_objects: usize,
    pub adaptive_static_hint_true_negative_bytes: usize,
    pub adaptive_static_hint_false_positive_objects: usize,
    pub adaptive_static_hint_false_positive_bytes: usize,
    pub adaptive_static_hint_false_negative_objects: usize,
    pub adaptive_static_hint_false_negative_bytes: usize,
    pub adaptive_static_hint_abstained_objects: usize,
    pub adaptive_static_hint_abstained_bytes: usize,
}

#[derive(Clone, Copy)]
struct SlotGeometry {
    slot_size: usize,
    payload_capacity: usize,
    region_capacity: usize,
    bucket: usize,
    adaptive_trailer: bool,
}

#[derive(Clone, Copy)]
struct ConfusionCounters {
    true_positive_objects: usize,
    true_positive_bytes: usize,
    true_negative_objects: usize,
    true_negative_bytes: usize,
    false_positive_objects: usize,
    false_positive_bytes: usize,
    false_negative_objects: usize,
    false_negative_bytes: usize,
}

impl ConfusionCounters {
    const fn new() -> Self {
        Self {
            true_positive_objects: 0,
            true_positive_bytes: 0,
            true_negative_objects: 0,
            true_negative_bytes: 0,
            false_positive_objects: 0,
            false_positive_bytes: 0,
            false_negative_objects: 0,
            false_negative_bytes: 0,
        }
    }

    #[inline]
    fn record(&mut self, predicted_positive: bool, actual_positive: bool, bytes: usize) {
        match (predicted_positive, actual_positive) {
            (true, true) => {
                self.true_positive_objects = self.true_positive_objects.saturating_add(1);
                self.true_positive_bytes = self.true_positive_bytes.saturating_add(bytes);
            }
            (false, false) => {
                self.true_negative_objects = self.true_negative_objects.saturating_add(1);
                self.true_negative_bytes = self.true_negative_bytes.saturating_add(bytes);
            }
            (true, false) => {
                self.false_positive_objects = self.false_positive_objects.saturating_add(1);
                self.false_positive_bytes = self.false_positive_bytes.saturating_add(bytes);
            }
            (false, true) => {
                self.false_negative_objects = self.false_negative_objects.saturating_add(1);
                self.false_negative_bytes = self.false_negative_bytes.saturating_add(bytes);
            }
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
#[repr(u8)]
enum AdaptivePrediction {
    Cold = 0,
    Short = 1,
    Long = 2,
}

impl AdaptivePrediction {
    #[inline]
    fn from_u8(value: u8) -> Option<Self> {
        match value {
            0 => Some(Self::Cold),
            1 => Some(Self::Short),
            2 => Some(Self::Long),
            _ => None,
        }
    }

    #[inline]
    fn placement_class(self) -> LifetimePlacementClass {
        match self {
            Self::Long => LifetimePlacementClass::LongLived,
            Self::Cold | Self::Short => LifetimePlacementClass::Ephemeral,
        }
    }
}

#[inline]
fn lifetime_class_from_u8(value: u8) -> Option<LifetimePlacementClass> {
    match value {
        0 => Some(LifetimePlacementClass::Unknown),
        1 => Some(LifetimePlacementClass::Ephemeral),
        2 => Some(LifetimePlacementClass::LongLived),
        _ => None,
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct AdaptiveSiteKey {
    callsite: u64,
    type_id: u64,
    module_id: u64,
    flags: u32,
    placement_hint: u16,
    payload_capacity: usize,
    align: usize,
}

impl AdaptiveSiteKey {
    const fn empty() -> Self {
        Self {
            callsite: 0,
            type_id: 0,
            module_id: 0,
            flags: 0,
            placement_hint: 0,
            payload_capacity: 0,
            align: 0,
        }
    }

    #[inline]
    fn from_metadata(
        metadata: AllocationMetadata,
        payload_capacity: usize,
        align: usize,
    ) -> Option<Self> {
        if metadata.callsite == 0 || !metadata.has_type() || metadata.requests(FLAG_DELAYED_FREE) {
            return None;
        }
        Some(Self {
            callsite: metadata.callsite,
            type_id: metadata.type_id,
            module_id: metadata.module_id,
            flags: metadata.flags,
            placement_hint: metadata.placement_hint,
            payload_capacity,
            align,
        })
    }

    #[inline]
    fn fingerprint(self) -> u64 {
        let mut hash = 0xcbf2_9ce4_8422_2325u64;
        for value in [
            self.callsite,
            self.type_id,
            self.module_id,
            self.flags as u64,
            self.placement_hint as u64,
            self.payload_capacity as u64,
            self.align as u64,
        ] {
            hash ^= value;
            hash = hash.wrapping_mul(0x0000_0100_0000_01b3);
        }
        if hash == 0 {
            1
        } else {
            hash
        }
    }
}

#[derive(Clone, Copy)]
struct AdaptiveSiteState {
    key: AdaptiveSiteKey,
    fingerprint: u64,
    short_votes: u32,
    long_votes: u32,
    decisive_samples: u32,
    censored_samples: u32,
    samples_since_transition: u32,
    allocations_since_sample: u32,
    tracked_inflight: u32,
    prediction: AdaptivePrediction,
    static_prior: LifetimePlacementClass,
    prior_conflict: bool,
}

impl AdaptiveSiteState {
    const fn empty() -> Self {
        Self {
            key: AdaptiveSiteKey::empty(),
            fingerprint: 0,
            short_votes: 0,
            long_votes: 0,
            decisive_samples: 0,
            censored_samples: 0,
            samples_since_transition: 0,
            allocations_since_sample: 0,
            tracked_inflight: 0,
            prediction: AdaptivePrediction::Cold,
            static_prior: LifetimePlacementClass::Unknown,
            prior_conflict: false,
        }
    }

    fn new(key: AdaptiveSiteKey, static_prior: LifetimePlacementClass) -> Self {
        let (short_votes, long_votes) = match static_prior {
            LifetimePlacementClass::Unknown => (1, 1),
            LifetimePlacementClass::Ephemeral => (3, 1),
            LifetimePlacementClass::LongLived => (1, 3),
        };
        Self {
            key,
            fingerprint: key.fingerprint(),
            short_votes,
            long_votes,
            decisive_samples: 0,
            censored_samples: 0,
            samples_since_transition: 0,
            allocations_since_sample: 0,
            tracked_inflight: 0,
            prediction: AdaptivePrediction::Cold,
            static_prior,
            prior_conflict: false,
        }
    }

    #[inline]
    fn is_empty(self) -> bool {
        self.fingerprint == 0
    }

    #[inline]
    fn note_prior(&mut self, incoming: LifetimePlacementClass) -> bool {
        if incoming == LifetimePlacementClass::Unknown || self.prior_conflict {
            return false;
        }
        if self.static_prior == LifetimePlacementClass::Unknown {
            self.static_prior = incoming;
            match incoming {
                LifetimePlacementClass::Ephemeral => {
                    self.short_votes = self.short_votes.saturating_add(2)
                }
                LifetimePlacementClass::LongLived => {
                    self.long_votes = self.long_votes.saturating_add(2)
                }
                LifetimePlacementClass::Unknown => unreachable!(),
            }
            return false;
        }
        if self.static_prior != incoming && !self.prior_conflict {
            self.prior_conflict = true;
            self.static_prior = LifetimePlacementClass::Unknown;
            self.short_votes = 1;
            self.long_votes = 1;
            self.decisive_samples = 0;
            self.censored_samples = 0;
            self.prediction = AdaptivePrediction::Cold;
            self.samples_since_transition = 0;
            self.allocations_since_sample = 0;
            return true;
        }
        false
    }

    #[inline]
    fn effective_prediction(self) -> AdaptivePrediction {
        self.prediction
    }

    #[inline]
    fn should_track_allocation(&mut self) -> bool {
        match self.effective_prediction() {
            AdaptivePrediction::Cold => {
                if self.tracked_inflight >= ADAPTIVE_COLD_MAX_INFLIGHT {
                    return false;
                }
                let observed_samples = self.decisive_samples.saturating_add(self.censored_samples);
                if observed_samples < ADAPTIVE_MIN_DECISIVE_SAMPLES {
                    self.allocations_since_sample = 0;
                    return true;
                }
            }
            AdaptivePrediction::Long => {
                self.allocations_since_sample = 0;
                return true;
            }
            AdaptivePrediction::Short => {}
        }
        self.allocations_since_sample = self.allocations_since_sample.saturating_add(1);
        if self.allocations_since_sample < ADAPTIVE_SHORT_SAMPLE_INTERVAL {
            return false;
        }
        self.allocations_since_sample = 0;
        true
    }

    #[inline]
    fn note_tracked_allocation(&mut self) {
        self.tracked_inflight = self.tracked_inflight.saturating_add(1);
    }

    #[inline]
    fn note_tracked_deallocation(&mut self) {
        self.tracked_inflight = self.tracked_inflight.saturating_sub(1);
    }

    fn observe(&mut self, actual_long: Option<bool>) -> AdaptiveTransition {
        let Some(actual_long) = actual_long else {
            self.censored_samples = self.censored_samples.saturating_add(1);
            return AdaptiveTransition::None;
        };
        if actual_long {
            self.long_votes = self.long_votes.saturating_add(1);
        } else {
            self.short_votes = self.short_votes.saturating_add(1);
        }
        self.decisive_samples = self.decisive_samples.saturating_add(1);
        self.samples_since_transition = self.samples_since_transition.saturating_add(1);

        if self.decisive_samples % ADAPTIVE_COUNTER_DECAY_INTERVAL == 0 {
            self.short_votes = core::cmp::max(1, self.short_votes / 2);
            self.long_votes = core::cmp::max(1, self.long_votes / 2);
        }
        if self.decisive_samples < ADAPTIVE_MIN_DECISIVE_SAMPLES {
            return AdaptiveTransition::None;
        }

        let total = self.short_votes.saturating_add(self.long_votes) as u64;
        let long_percent = (self.long_votes as u64).saturating_mul(100) / total;
        match self.prediction {
            AdaptivePrediction::Cold if long_percent >= 80 => {
                self.prediction = AdaptivePrediction::Long;
                self.samples_since_transition = 0;
                AdaptiveTransition::PromotedLong
            }
            AdaptivePrediction::Cold if long_percent <= 20 => {
                self.prediction = AdaptivePrediction::Short;
                self.samples_since_transition = 0;
                AdaptiveTransition::PromotedShort
            }
            AdaptivePrediction::Long
                if self.samples_since_transition >= ADAPTIVE_MIN_SAMPLES_AFTER_TRANSITION
                    && long_percent < 60 =>
            {
                self.prediction = AdaptivePrediction::Cold;
                self.samples_since_transition = 0;
                AdaptiveTransition::Demoted
            }
            AdaptivePrediction::Short
                if self.samples_since_transition >= ADAPTIVE_MIN_SAMPLES_AFTER_TRANSITION
                    && long_percent > 40 =>
            {
                self.prediction = AdaptivePrediction::Cold;
                self.samples_since_transition = 0;
                AdaptiveTransition::Demoted
            }
            _ => AdaptiveTransition::None,
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum AdaptiveTransition {
    None,
    PromotedShort,
    PromotedLong,
    Demoted,
}

#[derive(Clone, Copy)]
#[repr(C)]
struct AdaptiveSlotTrailer {
    birth_pressure: u64,
    site_fingerprint: u64,
    site_index: u32,
    requested_size: u32,
    prediction: u8,
    static_hint: u8,
    flags: u16,
    checksum: u32,
}

#[derive(Clone, Copy)]
struct AdaptiveAllocationRecord {
    birth_pressure: u64,
    site_fingerprint: u64,
    site_index: usize,
    requested_size: usize,
    prediction: AdaptivePrediction,
    static_hint: LifetimePlacementClass,
}

impl AdaptiveSlotTrailer {
    fn new(
        ptr: *mut u8,
        birth_pressure: u64,
        site_fingerprint: u64,
        site_index: usize,
        requested_size: usize,
        prediction: AdaptivePrediction,
        static_hint: LifetimePlacementClass,
    ) -> Self {
        let mut trailer = Self {
            birth_pressure,
            site_fingerprint,
            site_index: site_index as u32,
            requested_size: requested_size as u32,
            prediction: prediction as u8,
            static_hint: static_hint as u8,
            flags: ADAPTIVE_TRAILER_ACTIVE,
            checksum: 0,
        };
        trailer.checksum = trailer.expected_checksum(ptr);
        trailer
    }

    #[inline]
    fn expected_checksum(self, ptr: *mut u8) -> u32 {
        let mut hash = 0x811c_9dc5u32;
        for value in [
            self.birth_pressure,
            self.site_fingerprint,
            self.site_index as u64,
            self.requested_size as u64,
            self.prediction as u64,
            self.static_hint as u64,
            self.flags as u64,
            ptr as usize as u64,
        ] {
            hash ^= value as u32;
            hash = hash.wrapping_mul(0x0100_0193);
            hash ^= (value >> 32) as u32;
            hash = hash.wrapping_mul(0x0100_0193);
        }
        hash
    }

    #[inline]
    fn is_valid(self, ptr: *mut u8, payload_capacity: usize) -> bool {
        self.flags == ADAPTIVE_TRAILER_ACTIVE
            && self.requested_size as usize <= payload_capacity
            && (self.site_index as usize) < ADAPTIVE_SITE_SLOTS
            && AdaptivePrediction::from_u8(self.prediction).is_some()
            && lifetime_class_from_u8(self.static_hint).is_some()
            && self.checksum == self.expected_checksum(ptr)
    }
}

const _: () = assert!(size_of::<AdaptiveSlotTrailer>() == 32);

/// Match the semantic cache's exact reuse boundary. Callsite stays
/// diagnostic-only because allocation and matching Drop sites are distinct.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct ArenaIdentity {
    type_id: u64,
    module_id: u64,
    flags: u32,
    lifetime_hint: u16,
    placement_hint: u16,
}

impl ArenaIdentity {
    const fn unknown() -> Self {
        Self {
            type_id: 0,
            module_id: 0,
            flags: 0,
            lifetime_hint: 0,
            placement_hint: 0,
        }
    }

    const fn from_metadata(metadata: AllocationMetadata) -> Self {
        Self {
            type_id: metadata.type_id,
            module_id: metadata.module_id,
            flags: metadata.flags,
            lifetime_hint: metadata.lifetime_hint,
            placement_hint: metadata.placement_hint,
        }
    }
}

#[derive(Clone, Copy)]
struct IdentityRegion {
    identity: ArenaIdentity,
    /// Allocation epoch when every live slot is known to share one epoch.
    birth_epoch: usize,
    /// A non-cohort policy reused this region across allocation epochs while
    /// older slots remained live, so per-object death epochs are ambiguous.
    epoch_mixed: bool,
    next_unused: usize,
    live: usize,
    free_head: usize,
    assigned: bool,
}

impl IdentityRegion {
    const fn empty() -> Self {
        Self {
            identity: ArenaIdentity::unknown(),
            birth_epoch: 0,
            epoch_mixed: false,
            next_unused: 0,
            live: 0,
            free_head: NONE,
            assigned: false,
        }
    }

    #[inline]
    fn has_available_slot(self, capacity: usize) -> bool {
        self.free_head != NONE || self.next_unused < capacity
    }
}

#[derive(Clone, Copy)]
struct Extent {
    base: usize,
    slot_size: usize,
    payload_capacity: usize,
    region_capacity: usize,
    live: usize,
    bucket: usize,
    regions: [IdentityRegion; IDENTITY_REGIONS_PER_EXTENT],
    lifetime_class: LifetimePlacementClass,
    /// Nonzero only when policy forbids cross-epoch extent mixing.
    cohort_epoch: usize,
    backing: ActualBacking,
    adaptive_trailer: bool,
    available_prev: usize,
    available_next: usize,
    on_available_list: bool,
    next_free_descriptor: usize,
}

impl Extent {
    const fn empty() -> Self {
        Self {
            base: 0,
            slot_size: 0,
            payload_capacity: 0,
            region_capacity: 0,
            live: 0,
            bucket: 0,
            regions: [IdentityRegion::empty(); IDENTITY_REGIONS_PER_EXTENT],
            lifetime_class: LifetimePlacementClass::Unknown,
            cohort_epoch: 0,
            backing: ActualBacking::Unmapped,
            adaptive_trailer: false,
            available_prev: NONE,
            available_next: NONE,
            on_available_list: false,
            next_free_descriptor: NONE,
        }
    }

    #[inline]
    fn in_use(self) -> bool {
        self.base != 0
    }

    #[inline]
    fn matching_region_with_space(
        &self,
        identity: ArenaIdentity,
        birth_epoch: usize,
        require_epoch_match: bool,
    ) -> Option<usize> {
        self.regions.iter().position(|region| {
            region.assigned
                && region.identity == identity
                && (!require_epoch_match || region.birth_epoch == birth_epoch)
                && region.has_available_slot(self.region_capacity)
        })
    }

    #[inline]
    fn unassigned_region(&self) -> Option<usize> {
        self.regions.iter().position(|region| !region.assigned)
    }

    #[inline]
    fn has_available_slot(&self) -> bool {
        self.unassigned_region().is_some()
            || self
                .regions
                .iter()
                .any(|region| region.assigned && region.has_available_slot(self.region_capacity))
    }
}

#[inline]
fn thp_promotion_eligibility(extent: &Extent, current_epoch: usize) -> ThpPromotionEligibility {
    if !extent.in_use()
        || extent.live == 0
        || extent.cohort_epoch == 0
        || extent.cohort_epoch >= current_epoch
        || extent.backing.is_thp_confirmed_at_collapse()
        || !matches!(
            extent.backing,
            ActualBacking::ThpCandidateNoHugepage
                | ActualBacking::ThpCandidateNoHugepageAdviceFailed
                | ActualBacking::ThpAdvisedUnverified
        )
    {
        return ThpPromotionEligibility::Ineligible;
    }
    if extent.live.saturating_mul(extent.slot_size) < THP_PROMOTION_MIN_LIVE_BYTES {
        ThpPromotionEligibility::LowOccupancy
    } else {
        ThpPromotionEligibility::Eligible
    }
}

struct LifetimeArenaState {
    extents: [Extent; MAX_EXTENTS],
    lookup: [usize; EXTENT_LOOKUP_SLOTS],
    available_heads: [usize; BUCKET_COUNT],
    next_unused_descriptor: usize,
    free_descriptor_head: usize,
    current_epoch: usize,
    phase_advances: usize,
    epoch_cohort_extent_mappings: usize,
    routed_allocations: usize,
    routed_deallocations: usize,
    unknown_bypasses: usize,
    unknown_bypass_requested_bytes: usize,
    unsupported_layout_bypasses: usize,
    allocation_fallbacks: usize,
    slot_reuse_hits: usize,
    slot_bump_allocations: usize,
    identity_region_assignments: usize,
    identity_region_releases: usize,
    ordinary_extent_mappings: usize,
    hugetlb_extent_mappings: usize,
    hugetlb_fallback_extent_mappings: usize,
    thp_extent_mappings: usize,
    thp_candidate_extent_mappings: usize,
    thp_advice_attempts: usize,
    thp_advice_successes: usize,
    thp_advice_errors: usize,
    thp_collapse_eligible_extents: usize,
    thp_collapse_low_occupancy_skips: usize,
    thp_collapse_attempts: usize,
    thp_collapse_successes: usize,
    thp_collapse_errors: usize,
    thp_collapse_last_error_code: isize,
    mapping_failures: usize,
    nohugepage_advice_failures: usize,
    extent_unmaps: usize,
    extent_unmap_failures: usize,
    current_extents: usize,
    peak_extents: usize,
    current_ordinary_extents: usize,
    peak_ordinary_extents: usize,
    current_hugetlb_extents: usize,
    peak_hugetlb_extents: usize,
    current_thp_extents: usize,
    peak_thp_extents: usize,
    current_thp_collapse_confirmed_extents: usize,
    peak_thp_collapse_confirmed_extents: usize,
    live_objects: usize,
    live_ephemeral_objects: usize,
    live_long_lived_objects: usize,
    live_slot_bytes: usize,
    runtime_validated_objects: usize,
    runtime_validated_bytes: usize,
    runtime_validation_excluded_objects: usize,
    runtime_validation_excluded_bytes: usize,
    runtime_delayed_free_excluded_objects: usize,
    runtime_delayed_free_excluded_bytes: usize,
    runtime_mixed_epoch_excluded_objects: usize,
    runtime_mixed_epoch_excluded_bytes: usize,
    predictor_confusion: ConfusionCounters,
    placement_confusion: ConfusionCounters,
    current_identity_regions: usize,
    peak_identity_regions: usize,
    adaptive_sites: [AdaptiveSiteState; ADAPTIVE_SITE_SLOTS],
    adaptive_pressure_bytes: u64,
    adaptive_epoch_advances: usize,
    adaptive_site_count: usize,
    adaptive_eligible_allocations: usize,
    adaptive_training_allocations: usize,
    adaptive_cold_bypassed_allocations: usize,
    adaptive_short_routed_allocations: usize,
    adaptive_short_bypassed_allocations: usize,
    adaptive_long_routed_allocations: usize,
    adaptive_missing_identity_bypasses: usize,
    adaptive_site_table_bypasses: usize,
    adaptive_prior_conflicts: usize,
    adaptive_live_trailers: usize,
    adaptive_trailer_corruptions: usize,
    adaptive_short_observations: usize,
    adaptive_long_observations: usize,
    adaptive_censored_observations: usize,
    adaptive_decisive_observation_bytes: usize,
    adaptive_promotions: usize,
    adaptive_demotions: usize,
    adaptive_prior_corrections: usize,
    adaptive_predictor_confusion: ConfusionCounters,
    adaptive_static_hint_confusion: ConfusionCounters,
    adaptive_static_hint_abstained_objects: usize,
    adaptive_static_hint_abstained_bytes: usize,
}

impl LifetimeArenaState {
    const fn new() -> Self {
        Self {
            extents: [Extent::empty(); MAX_EXTENTS],
            lookup: [NONE; EXTENT_LOOKUP_SLOTS],
            available_heads: [NONE; BUCKET_COUNT],
            next_unused_descriptor: 0,
            free_descriptor_head: NONE,
            current_epoch: 1,
            phase_advances: 0,
            epoch_cohort_extent_mappings: 0,
            routed_allocations: 0,
            routed_deallocations: 0,
            unknown_bypasses: 0,
            unknown_bypass_requested_bytes: 0,
            unsupported_layout_bypasses: 0,
            allocation_fallbacks: 0,
            slot_reuse_hits: 0,
            slot_bump_allocations: 0,
            identity_region_assignments: 0,
            identity_region_releases: 0,
            ordinary_extent_mappings: 0,
            hugetlb_extent_mappings: 0,
            hugetlb_fallback_extent_mappings: 0,
            thp_extent_mappings: 0,
            thp_candidate_extent_mappings: 0,
            thp_advice_attempts: 0,
            thp_advice_successes: 0,
            thp_advice_errors: 0,
            thp_collapse_eligible_extents: 0,
            thp_collapse_low_occupancy_skips: 0,
            thp_collapse_attempts: 0,
            thp_collapse_successes: 0,
            thp_collapse_errors: 0,
            thp_collapse_last_error_code: 0,
            mapping_failures: 0,
            nohugepage_advice_failures: 0,
            extent_unmaps: 0,
            extent_unmap_failures: 0,
            current_extents: 0,
            peak_extents: 0,
            current_ordinary_extents: 0,
            peak_ordinary_extents: 0,
            current_hugetlb_extents: 0,
            peak_hugetlb_extents: 0,
            current_thp_extents: 0,
            peak_thp_extents: 0,
            current_thp_collapse_confirmed_extents: 0,
            peak_thp_collapse_confirmed_extents: 0,
            live_objects: 0,
            live_ephemeral_objects: 0,
            live_long_lived_objects: 0,
            live_slot_bytes: 0,
            runtime_validated_objects: 0,
            runtime_validated_bytes: 0,
            runtime_validation_excluded_objects: 0,
            runtime_validation_excluded_bytes: 0,
            runtime_delayed_free_excluded_objects: 0,
            runtime_delayed_free_excluded_bytes: 0,
            runtime_mixed_epoch_excluded_objects: 0,
            runtime_mixed_epoch_excluded_bytes: 0,
            predictor_confusion: ConfusionCounters::new(),
            placement_confusion: ConfusionCounters::new(),
            current_identity_regions: 0,
            peak_identity_regions: 0,
            adaptive_sites: [AdaptiveSiteState::empty(); ADAPTIVE_SITE_SLOTS],
            adaptive_pressure_bytes: 0,
            adaptive_epoch_advances: 0,
            adaptive_site_count: 0,
            adaptive_eligible_allocations: 0,
            adaptive_training_allocations: 0,
            adaptive_cold_bypassed_allocations: 0,
            adaptive_short_routed_allocations: 0,
            adaptive_short_bypassed_allocations: 0,
            adaptive_long_routed_allocations: 0,
            adaptive_missing_identity_bypasses: 0,
            adaptive_site_table_bypasses: 0,
            adaptive_prior_conflicts: 0,
            adaptive_live_trailers: 0,
            adaptive_trailer_corruptions: 0,
            adaptive_short_observations: 0,
            adaptive_long_observations: 0,
            adaptive_censored_observations: 0,
            adaptive_decisive_observation_bytes: 0,
            adaptive_promotions: 0,
            adaptive_demotions: 0,
            adaptive_prior_corrections: 0,
            adaptive_predictor_confusion: ConfusionCounters::new(),
            adaptive_static_hint_confusion: ConfusionCounters::new(),
            adaptive_static_hint_abstained_objects: 0,
            adaptive_static_hint_abstained_bytes: 0,
        }
    }

    #[inline]
    fn reset_counters(&mut self, preserve_adaptive_model: bool) {
        self.current_epoch = 1;
        self.phase_advances = 0;
        self.epoch_cohort_extent_mappings = 0;
        self.routed_allocations = 0;
        self.routed_deallocations = 0;
        self.unknown_bypasses = 0;
        self.unknown_bypass_requested_bytes = 0;
        self.unsupported_layout_bypasses = 0;
        self.allocation_fallbacks = 0;
        self.slot_reuse_hits = 0;
        self.slot_bump_allocations = 0;
        self.identity_region_assignments = 0;
        self.identity_region_releases = 0;
        self.ordinary_extent_mappings = 0;
        self.hugetlb_extent_mappings = 0;
        self.hugetlb_fallback_extent_mappings = 0;
        self.thp_extent_mappings = 0;
        self.thp_candidate_extent_mappings = 0;
        self.thp_advice_attempts = 0;
        self.thp_advice_successes = 0;
        self.thp_advice_errors = 0;
        self.thp_collapse_eligible_extents = 0;
        self.thp_collapse_low_occupancy_skips = 0;
        self.thp_collapse_attempts = 0;
        self.thp_collapse_successes = 0;
        self.thp_collapse_errors = 0;
        self.thp_collapse_last_error_code = 0;
        self.mapping_failures = 0;
        self.nohugepage_advice_failures = 0;
        self.extent_unmaps = 0;
        self.extent_unmap_failures = 0;
        self.runtime_validated_objects = 0;
        self.runtime_validated_bytes = 0;
        self.runtime_validation_excluded_objects = 0;
        self.runtime_validation_excluded_bytes = 0;
        self.runtime_delayed_free_excluded_objects = 0;
        self.runtime_delayed_free_excluded_bytes = 0;
        self.runtime_mixed_epoch_excluded_objects = 0;
        self.runtime_mixed_epoch_excluded_bytes = 0;
        self.predictor_confusion = ConfusionCounters::new();
        self.placement_confusion = ConfusionCounters::new();
        if !preserve_adaptive_model {
            self.adaptive_sites = [AdaptiveSiteState::empty(); ADAPTIVE_SITE_SLOTS];
            self.adaptive_site_count = 0;
        } else {
            for site in self
                .adaptive_sites
                .iter_mut()
                .filter(|site| !site.is_empty())
            {
                site.tracked_inflight = 0;
            }
        }
        self.adaptive_pressure_bytes = 0;
        self.adaptive_epoch_advances = 0;
        self.adaptive_eligible_allocations = 0;
        self.adaptive_training_allocations = 0;
        self.adaptive_cold_bypassed_allocations = 0;
        self.adaptive_short_routed_allocations = 0;
        self.adaptive_short_bypassed_allocations = 0;
        self.adaptive_long_routed_allocations = 0;
        self.adaptive_missing_identity_bypasses = 0;
        self.adaptive_site_table_bypasses = 0;
        self.adaptive_prior_conflicts = 0;
        self.adaptive_live_trailers = 0;
        self.adaptive_trailer_corruptions = 0;
        self.adaptive_short_observations = 0;
        self.adaptive_long_observations = 0;
        self.adaptive_censored_observations = 0;
        self.adaptive_decisive_observation_bytes = 0;
        self.adaptive_promotions = 0;
        self.adaptive_demotions = 0;
        self.adaptive_prior_corrections = 0;
        self.adaptive_predictor_confusion = ConfusionCounters::new();
        self.adaptive_static_hint_confusion = ConfusionCounters::new();
        self.adaptive_static_hint_abstained_objects = 0;
        self.adaptive_static_hint_abstained_bytes = 0;
        self.peak_extents = self.current_extents;
        self.peak_ordinary_extents = self.current_ordinary_extents;
        self.peak_hugetlb_extents = self.current_hugetlb_extents;
        self.peak_thp_extents = self.current_thp_extents;
        self.peak_thp_collapse_confirmed_extents = self.current_thp_collapse_confirmed_extents;
        self.peak_identity_regions = self.current_identity_regions;
    }

    #[inline]
    fn snapshot(&self) -> LifetimeHugepageStatsSnapshot {
        let retained_bytes = self
            .current_extents
            .saturating_mul(LIFETIME_HUGEPAGE_EXTENT_BYTES);
        let assigned_region_bytes = self
            .current_identity_regions
            .saturating_mul(LIFETIME_HUGEPAGE_IDENTITY_REGION_BYTES);
        let unassigned_region_bytes = retained_bytes.saturating_sub(assigned_region_bytes);
        let cohort_pinned_unassigned_region_bytes =
            if lifetime_hugepage_policy() == LifetimeHugepagePolicy::EpochCohortHugepage {
                self.extents
                    .iter()
                    .filter(|extent| extent.in_use() && extent.cohort_epoch != self.current_epoch)
                    .map(|extent| {
                        extent
                            .regions
                            .iter()
                            .filter(|region| !region.assigned)
                            .count()
                            .saturating_mul(LIFETIME_HUGEPAGE_IDENTITY_REGION_BYTES)
                    })
                    .fold(0usize, usize::saturating_add)
            } else {
                0
            };
        let reusable_unassigned_region_bytes =
            unassigned_region_bytes.saturating_sub(cohort_pinned_unassigned_region_bytes);
        let assigned_region_slack_bytes =
            assigned_region_bytes.saturating_sub(self.live_slot_bytes);
        let retained_slack_bytes = retained_bytes.saturating_sub(self.live_slot_bytes);
        let mut adaptive_cold_sites = 0usize;
        let mut adaptive_short_sites = 0usize;
        let mut adaptive_long_sites = 0usize;
        for site in self.adaptive_sites.iter().filter(|site| !site.is_empty()) {
            match site.effective_prediction() {
                AdaptivePrediction::Cold => adaptive_cold_sites += 1,
                AdaptivePrediction::Short => adaptive_short_sites += 1,
                AdaptivePrediction::Long => adaptive_long_sites += 1,
            }
        }
        LifetimeHugepageStatsSnapshot {
            policy: lifetime_hugepage_policy(),
            backend: lifetime_hugepage_backend(),
            extent_bytes: LIFETIME_HUGEPAGE_EXTENT_BYTES,
            current_epoch: self.current_epoch,
            phase_advances: self.phase_advances,
            epoch_cohort_extent_mappings: self.epoch_cohort_extent_mappings,
            routed_allocations: self.routed_allocations,
            routed_deallocations: self.routed_deallocations,
            unknown_bypasses: self.unknown_bypasses,
            unknown_bypass_requested_bytes: self.unknown_bypass_requested_bytes,
            unsupported_layout_bypasses: self.unsupported_layout_bypasses,
            allocation_fallbacks: self.allocation_fallbacks,
            slot_reuse_hits: self.slot_reuse_hits,
            slot_bump_allocations: self.slot_bump_allocations,
            identity_region_assignments: self.identity_region_assignments,
            identity_region_releases: self.identity_region_releases,
            ordinary_extent_mappings: self.ordinary_extent_mappings,
            hugetlb_extent_mappings: self.hugetlb_extent_mappings,
            hugetlb_fallback_extent_mappings: self.hugetlb_fallback_extent_mappings,
            thp_extent_mappings: self.thp_extent_mappings,
            thp_candidate_extent_mappings: self.thp_candidate_extent_mappings,
            thp_advice_attempts: self.thp_advice_attempts,
            thp_advice_successes: self.thp_advice_successes,
            thp_advice_errors: self.thp_advice_errors,
            thp_collapse_eligible_extents: self.thp_collapse_eligible_extents,
            thp_collapse_low_occupancy_skips: self.thp_collapse_low_occupancy_skips,
            thp_collapse_attempts: self.thp_collapse_attempts,
            thp_collapse_successes: self.thp_collapse_successes,
            thp_collapse_errors: self.thp_collapse_errors,
            thp_collapse_last_error_code: self.thp_collapse_last_error_code,
            mapping_failures: self.mapping_failures,
            nohugepage_advice_failures: self.nohugepage_advice_failures,
            extent_unmaps: self.extent_unmaps,
            extent_unmap_failures: self.extent_unmap_failures,
            current_extents: self.current_extents,
            peak_extents: self.peak_extents,
            current_ordinary_extents: self.current_ordinary_extents,
            peak_ordinary_extents: self.peak_ordinary_extents,
            current_hugetlb_extents: self.current_hugetlb_extents,
            peak_hugetlb_extents: self.peak_hugetlb_extents,
            current_thp_extents: self.current_thp_extents,
            peak_thp_extents: self.peak_thp_extents,
            current_thp_collapse_confirmed_extents: self.current_thp_collapse_confirmed_extents,
            peak_thp_collapse_confirmed_extents: self.peak_thp_collapse_confirmed_extents,
            live_objects: self.live_objects,
            live_ephemeral_objects: self.live_ephemeral_objects,
            live_long_lived_objects: self.live_long_lived_objects,
            live_slot_bytes: self.live_slot_bytes,
            runtime_validated_objects: self.runtime_validated_objects,
            runtime_validated_bytes: self.runtime_validated_bytes,
            runtime_validation_excluded_objects: self.runtime_validation_excluded_objects,
            runtime_validation_excluded_bytes: self.runtime_validation_excluded_bytes,
            runtime_delayed_free_excluded_objects: self.runtime_delayed_free_excluded_objects,
            runtime_delayed_free_excluded_bytes: self.runtime_delayed_free_excluded_bytes,
            runtime_mixed_epoch_excluded_objects: self.runtime_mixed_epoch_excluded_objects,
            runtime_mixed_epoch_excluded_bytes: self.runtime_mixed_epoch_excluded_bytes,
            predictor_true_positive_objects: self.predictor_confusion.true_positive_objects,
            predictor_true_positive_bytes: self.predictor_confusion.true_positive_bytes,
            predictor_true_negative_objects: self.predictor_confusion.true_negative_objects,
            predictor_true_negative_bytes: self.predictor_confusion.true_negative_bytes,
            predictor_false_positive_objects: self.predictor_confusion.false_positive_objects,
            predictor_false_positive_bytes: self.predictor_confusion.false_positive_bytes,
            predictor_false_negative_objects: self.predictor_confusion.false_negative_objects,
            predictor_false_negative_bytes: self.predictor_confusion.false_negative_bytes,
            placement_true_positive_objects: self.placement_confusion.true_positive_objects,
            placement_true_positive_bytes: self.placement_confusion.true_positive_bytes,
            placement_true_negative_objects: self.placement_confusion.true_negative_objects,
            placement_true_negative_bytes: self.placement_confusion.true_negative_bytes,
            placement_false_positive_objects: self.placement_confusion.false_positive_objects,
            placement_false_positive_bytes: self.placement_confusion.false_positive_bytes,
            placement_false_negative_objects: self.placement_confusion.false_negative_objects,
            placement_false_negative_bytes: self.placement_confusion.false_negative_bytes,
            current_identity_regions: self.current_identity_regions,
            peak_identity_regions: self.peak_identity_regions,
            retained_bytes,
            reusable_unassigned_region_bytes,
            cohort_pinned_unassigned_region_bytes,
            assigned_region_slack_bytes,
            retained_slack_bytes,
            stranded_bytes: retained_slack_bytes,
            all_mappings_released: self.current_extents == 0 && self.live_objects == 0,
            adaptive_pressure_bytes: self.adaptive_pressure_bytes,
            adaptive_pressure_epoch: (self.adaptive_pressure_bytes / ADAPTIVE_EPOCH_BYTES) as usize,
            adaptive_epoch_advances: self.adaptive_epoch_advances,
            adaptive_site_count: self.adaptive_site_count,
            adaptive_cold_sites,
            adaptive_short_sites,
            adaptive_long_sites,
            adaptive_eligible_allocations: self.adaptive_eligible_allocations,
            adaptive_training_allocations: self.adaptive_training_allocations,
            adaptive_cold_bypassed_allocations: self.adaptive_cold_bypassed_allocations,
            adaptive_short_routed_allocations: self.adaptive_short_routed_allocations,
            adaptive_short_bypassed_allocations: self.adaptive_short_bypassed_allocations,
            adaptive_long_routed_allocations: self.adaptive_long_routed_allocations,
            adaptive_missing_identity_bypasses: self.adaptive_missing_identity_bypasses,
            adaptive_site_table_bypasses: self.adaptive_site_table_bypasses,
            adaptive_prior_conflicts: self.adaptive_prior_conflicts,
            adaptive_live_trailers: self.adaptive_live_trailers,
            adaptive_trailer_corruptions: self.adaptive_trailer_corruptions,
            adaptive_short_observations: self.adaptive_short_observations,
            adaptive_long_observations: self.adaptive_long_observations,
            adaptive_censored_observations: self.adaptive_censored_observations,
            adaptive_decisive_observation_bytes: self.adaptive_decisive_observation_bytes,
            adaptive_promotions: self.adaptive_promotions,
            adaptive_demotions: self.adaptive_demotions,
            adaptive_prior_corrections: self.adaptive_prior_corrections,
            adaptive_predictor_true_positive_objects: self
                .adaptive_predictor_confusion
                .true_positive_objects,
            adaptive_predictor_true_positive_bytes: self
                .adaptive_predictor_confusion
                .true_positive_bytes,
            adaptive_predictor_true_negative_objects: self
                .adaptive_predictor_confusion
                .true_negative_objects,
            adaptive_predictor_true_negative_bytes: self
                .adaptive_predictor_confusion
                .true_negative_bytes,
            adaptive_predictor_false_positive_objects: self
                .adaptive_predictor_confusion
                .false_positive_objects,
            adaptive_predictor_false_positive_bytes: self
                .adaptive_predictor_confusion
                .false_positive_bytes,
            adaptive_predictor_false_negative_objects: self
                .adaptive_predictor_confusion
                .false_negative_objects,
            adaptive_predictor_false_negative_bytes: self
                .adaptive_predictor_confusion
                .false_negative_bytes,
            adaptive_static_hint_true_positive_objects: self
                .adaptive_static_hint_confusion
                .true_positive_objects,
            adaptive_static_hint_true_positive_bytes: self
                .adaptive_static_hint_confusion
                .true_positive_bytes,
            adaptive_static_hint_true_negative_objects: self
                .adaptive_static_hint_confusion
                .true_negative_objects,
            adaptive_static_hint_true_negative_bytes: self
                .adaptive_static_hint_confusion
                .true_negative_bytes,
            adaptive_static_hint_false_positive_objects: self
                .adaptive_static_hint_confusion
                .false_positive_objects,
            adaptive_static_hint_false_positive_bytes: self
                .adaptive_static_hint_confusion
                .false_positive_bytes,
            adaptive_static_hint_false_negative_objects: self
                .adaptive_static_hint_confusion
                .false_negative_objects,
            adaptive_static_hint_false_negative_bytes: self
                .adaptive_static_hint_confusion
                .false_negative_bytes,
            adaptive_static_hint_abstained_objects: self.adaptive_static_hint_abstained_objects,
            adaptive_static_hint_abstained_bytes: self.adaptive_static_hint_abstained_bytes,
        }
    }

    fn adaptive_site_slot(
        &mut self,
        key: AdaptiveSiteKey,
        static_prior: LifetimePlacementClass,
    ) -> Option<usize> {
        let fingerprint = key.fingerprint();
        let start = fingerprint as usize & (ADAPTIVE_SITE_SLOTS - 1);
        for offset in 0..ADAPTIVE_SITE_PROBE_LIMIT {
            let idx = (start + offset) & (ADAPTIVE_SITE_SLOTS - 1);
            if self.adaptive_sites[idx].is_empty() {
                self.adaptive_sites[idx] = AdaptiveSiteState::new(key, static_prior);
                self.adaptive_site_count = self.adaptive_site_count.saturating_add(1);
                return Some(idx);
            }
            if self.adaptive_sites[idx].fingerprint == fingerprint
                && self.adaptive_sites[idx].key == key
            {
                if self.adaptive_sites[idx].note_prior(static_prior) {
                    self.adaptive_prior_conflicts = self.adaptive_prior_conflicts.saturating_add(1);
                }
                return Some(idx);
            }
        }
        self.adaptive_site_table_bypasses = self.adaptive_site_table_bypasses.saturating_add(1);
        None
    }

    #[inline]
    fn adaptive_note_pressure(&mut self, payload_capacity: usize) -> u64 {
        let old_epoch = self.adaptive_pressure_bytes / ADAPTIVE_EPOCH_BYTES;
        self.adaptive_pressure_bytes = self
            .adaptive_pressure_bytes
            .saturating_add(payload_capacity as u64);
        let new_epoch = self.adaptive_pressure_bytes / ADAPTIVE_EPOCH_BYTES;
        self.adaptive_epoch_advances = self
            .adaptive_epoch_advances
            .saturating_add(new_epoch.saturating_sub(old_epoch) as usize);
        self.adaptive_pressure_bytes
    }

    #[inline]
    fn adaptive_note_bypass(&mut self, payload_capacity: usize, prediction: AdaptivePrediction) {
        self.adaptive_note_pressure(payload_capacity);
        self.adaptive_eligible_allocations = self.adaptive_eligible_allocations.saturating_add(1);
        match prediction {
            AdaptivePrediction::Cold => {
                self.adaptive_cold_bypassed_allocations =
                    self.adaptive_cold_bypassed_allocations.saturating_add(1)
            }
            AdaptivePrediction::Short => {
                self.adaptive_short_bypassed_allocations =
                    self.adaptive_short_bypassed_allocations.saturating_add(1)
            }
            AdaptivePrediction::Long => unreachable!("learned-long allocation bypassed tracking"),
        }
    }

    #[inline]
    fn adaptive_note_allocation(
        &mut self,
        site_idx: usize,
        payload_capacity: usize,
        prediction: AdaptivePrediction,
    ) -> u64 {
        let birth_pressure = self.adaptive_note_pressure(payload_capacity);
        self.adaptive_sites[site_idx].note_tracked_allocation();
        self.adaptive_eligible_allocations = self.adaptive_eligible_allocations.saturating_add(1);
        self.adaptive_live_trailers = self.adaptive_live_trailers.saturating_add(1);
        match prediction {
            AdaptivePrediction::Cold => {
                self.adaptive_training_allocations =
                    self.adaptive_training_allocations.saturating_add(1)
            }
            AdaptivePrediction::Short => {
                self.adaptive_short_routed_allocations =
                    self.adaptive_short_routed_allocations.saturating_add(1)
            }
            AdaptivePrediction::Long => {
                self.adaptive_long_routed_allocations =
                    self.adaptive_long_routed_allocations.saturating_add(1)
            }
        }
        birth_pressure
    }

    fn adaptive_note_deallocation(
        &mut self,
        ptr: *mut u8,
        payload_capacity: usize,
        slot_size: usize,
        backing: ActualBacking,
        trailer: AdaptiveSlotTrailer,
    ) {
        self.adaptive_live_trailers = self.adaptive_live_trailers.saturating_sub(1);
        if !trailer.is_valid(ptr, payload_capacity) {
            self.adaptive_trailer_corruptions = self.adaptive_trailer_corruptions.saturating_add(1);
            return;
        }
        let site_idx = trailer.site_index as usize;
        if self.adaptive_sites[site_idx].is_empty()
            || self.adaptive_sites[site_idx].fingerprint != trailer.site_fingerprint
        {
            self.adaptive_trailer_corruptions = self.adaptive_trailer_corruptions.saturating_add(1);
            return;
        }
        self.adaptive_sites[site_idx].note_tracked_deallocation();

        let age_bytes = self
            .adaptive_pressure_bytes
            .saturating_sub(trailer.birth_pressure);
        let actual_long = adaptive_lifetime_outcome(age_bytes);
        match actual_long {
            Some(false) => {
                self.adaptive_short_observations =
                    self.adaptive_short_observations.saturating_add(1)
            }
            Some(true) => {
                self.adaptive_long_observations = self.adaptive_long_observations.saturating_add(1)
            }
            None => {
                self.adaptive_censored_observations =
                    self.adaptive_censored_observations.saturating_add(1)
            }
        }

        if let Some(actual_long) = actual_long {
            self.adaptive_decisive_observation_bytes = self
                .adaptive_decisive_observation_bytes
                .saturating_add(payload_capacity);
            self.runtime_validated_objects = self.runtime_validated_objects.saturating_add(1);
            self.runtime_validated_bytes = self.runtime_validated_bytes.saturating_add(slot_size);
            let prediction = AdaptivePrediction::from_u8(trailer.prediction)
                .expect("validated adaptive trailer has an invalid prediction");
            let predicted_long = prediction == AdaptivePrediction::Long;
            // Generic runtime validation describes the placement decision for
            // every decisive object. Cold is an explicit ordinary-placement
            // abstention and therefore counts as predicted short here. The
            // adaptive matrix below remains prediction-only and excludes Cold.
            self.predictor_confusion
                .record(predicted_long, actual_long, slot_size);
            if prediction != AdaptivePrediction::Cold {
                self.adaptive_predictor_confusion.record(
                    predicted_long,
                    actual_long,
                    payload_capacity,
                );
            }
            match lifetime_class_from_u8(trailer.static_hint)
                .expect("validated adaptive trailer has an invalid static hint")
            {
                LifetimePlacementClass::Unknown => {
                    self.adaptive_static_hint_abstained_objects = self
                        .adaptive_static_hint_abstained_objects
                        .saturating_add(1);
                    self.adaptive_static_hint_abstained_bytes = self
                        .adaptive_static_hint_abstained_bytes
                        .saturating_add(payload_capacity);
                }
                LifetimePlacementClass::Ephemeral => {
                    self.adaptive_static_hint_confusion
                        .record(false, actual_long, payload_capacity)
                }
                LifetimePlacementClass::LongLived => {
                    self.adaptive_static_hint_confusion
                        .record(true, actual_long, payload_capacity)
                }
            }
            self.placement_confusion.record(
                backing.is_large_page_confirmed(),
                actual_long,
                slot_size,
            );
        }

        let prior = self.adaptive_sites[site_idx].static_prior;
        let transition = self.adaptive_sites[site_idx].observe(actual_long);
        match transition {
            AdaptiveTransition::None => {}
            AdaptiveTransition::PromotedShort => {
                self.adaptive_promotions = self.adaptive_promotions.saturating_add(1);
                if prior == LifetimePlacementClass::LongLived {
                    self.adaptive_prior_corrections =
                        self.adaptive_prior_corrections.saturating_add(1);
                }
            }
            AdaptiveTransition::PromotedLong => {
                self.adaptive_promotions = self.adaptive_promotions.saturating_add(1);
                if prior == LifetimePlacementClass::Ephemeral {
                    self.adaptive_prior_corrections =
                        self.adaptive_prior_corrections.saturating_add(1);
                }
            }
            AdaptiveTransition::Demoted => {
                self.adaptive_demotions = self.adaptive_demotions.saturating_add(1)
            }
        }
    }

    #[inline]
    fn allocate_descriptor(&mut self) -> Option<usize> {
        if self.free_descriptor_head != NONE {
            let idx = self.free_descriptor_head;
            self.free_descriptor_head = self.extents[idx].next_free_descriptor;
            self.extents[idx] = Extent::empty();
            return Some(idx);
        }
        if self.next_unused_descriptor == MAX_EXTENTS {
            return None;
        }
        let idx = self.next_unused_descriptor;
        self.next_unused_descriptor += 1;
        Some(idx)
    }

    #[inline]
    fn release_descriptor(&mut self, idx: usize) {
        let mut empty = Extent::empty();
        empty.next_free_descriptor = self.free_descriptor_head;
        self.extents[idx] = empty;
        self.free_descriptor_head = idx;
    }

    #[inline]
    fn add_available(&mut self, idx: usize) {
        if self.extents[idx].on_available_list {
            return;
        }
        let bucket = self.extents[idx].bucket;
        let old_head = self.available_heads[bucket];
        self.extents[idx].available_prev = NONE;
        self.extents[idx].available_next = old_head;
        self.extents[idx].on_available_list = true;
        if old_head != NONE {
            self.extents[old_head].available_prev = idx;
        }
        self.available_heads[bucket] = idx;
    }

    #[inline]
    fn remove_available(&mut self, idx: usize) {
        if !self.extents[idx].on_available_list {
            return;
        }
        let bucket = self.extents[idx].bucket;
        let prev = self.extents[idx].available_prev;
        let next = self.extents[idx].available_next;
        if prev == NONE {
            self.available_heads[bucket] = next;
        } else {
            self.extents[prev].available_next = next;
        }
        if next != NONE {
            self.extents[next].available_prev = prev;
        }
        self.extents[idx].available_prev = NONE;
        self.extents[idx].available_next = NONE;
        self.extents[idx].on_available_list = false;
    }

    /// Epoch-cohort extents from older phases remain valid for their live
    /// objects, while new allocations must start from a current-epoch list.
    /// Detaching once per explicit phase keeps allocation search independent
    /// of the number of surviving historical cohorts.
    fn detach_available_epoch_cohorts(&mut self) {
        self.available_heads = [NONE; BUCKET_COUNT];
        for extent in self.extents[..self.next_unused_descriptor].iter_mut() {
            if extent.in_use() {
                extent.available_prev = NONE;
                extent.available_next = NONE;
                extent.on_available_list = false;
            }
        }
    }

    fn find_available(
        &mut self,
        bucket: usize,
        identity: ArenaIdentity,
        birth_epoch: usize,
        require_extent_cohort: bool,
    ) -> Option<usize> {
        let mut idx = self.available_heads[bucket];
        let mut unassigned_fallback = NONE;
        let mut visited = 0usize;
        while idx != NONE {
            let extent = &self.extents[idx];
            if extent.bucket != bucket || !extent.on_available_list {
                panic!("corrupt lifetime-arena available list");
            }
            let cohort_matches = !require_extent_cohort || extent.cohort_epoch == birth_epoch;
            if cohort_matches
                && extent
                    .matching_region_with_space(identity, birth_epoch, require_extent_cohort)
                    .is_some()
            {
                break;
            }
            if cohort_matches && unassigned_fallback == NONE && extent.unassigned_region().is_some()
            {
                unassigned_fallback = idx;
            }
            idx = extent.available_next;
            visited += 1;
            if visited > MAX_EXTENTS {
                panic!("cyclic lifetime-arena available list");
            }
        }
        let chosen = if idx != NONE {
            idx
        } else {
            unassigned_fallback
        };
        if chosen == NONE {
            return None;
        }
        if self.available_heads[bucket] != chosen {
            self.remove_available(chosen);
            self.add_available(chosen);
        }
        Some(chosen)
    }

    fn lookup_slot(base: usize) -> usize {
        let mut value = base >> 21;
        value ^= value >> 17;
        value = value.wrapping_mul(0x9e37_79b9_7f4a_7c15usize);
        (value ^ (value >> 29)) & EXTENT_LOOKUP_MASK
    }

    fn lookup_extent(&self, base: usize) -> Option<usize> {
        let start = Self::lookup_slot(base);
        let mut offset = 0usize;
        while offset < EXTENT_LOOKUP_SLOTS {
            let entry = self.lookup[(start + offset) & EXTENT_LOOKUP_MASK];
            if entry == NONE {
                return None;
            }
            if entry != TOMBSTONE
                && self.extents[entry].in_use()
                && self.extents[entry].base == base
            {
                return Some(entry);
            }
            offset += 1;
        }
        None
    }

    fn insert_lookup(&mut self, idx: usize) -> bool {
        let base = self.extents[idx].base;
        let start = Self::lookup_slot(base);
        let mut first_tombstone = NONE;
        let mut offset = 0usize;
        while offset < EXTENT_LOOKUP_SLOTS {
            let slot = (start + offset) & EXTENT_LOOKUP_MASK;
            let entry = self.lookup[slot];
            if entry == TOMBSTONE && first_tombstone == NONE {
                first_tombstone = slot;
            } else if entry == NONE {
                self.lookup[if first_tombstone == NONE {
                    slot
                } else {
                    first_tombstone
                }] = idx;
                return true;
            } else if entry != TOMBSTONE && self.extents[entry].base == base {
                return false;
            }
            offset += 1;
        }
        if first_tombstone != NONE {
            self.lookup[first_tombstone] = idx;
            true
        } else {
            false
        }
    }

    fn remove_lookup(&mut self, idx: usize) -> bool {
        let base = self.extents[idx].base;
        let start = Self::lookup_slot(base);
        let mut offset = 0usize;
        while offset < EXTENT_LOOKUP_SLOTS {
            let slot = (start + offset) & EXTENT_LOOKUP_MASK;
            let entry = self.lookup[slot];
            if entry == NONE {
                return false;
            }
            if entry == idx {
                self.lookup[slot] = TOMBSTONE;
                return true;
            }
            offset += 1;
        }
        false
    }

    fn note_mapped_extent(&mut self, backing: ActualBacking) {
        self.current_extents = self.current_extents.saturating_add(1);
        ACTIVE_EXTENTS.fetch_add(1, Ordering::Release);
        self.peak_extents = core::cmp::max(self.peak_extents, self.current_extents);
        if backing.is_hugetlb() {
            self.hugetlb_extent_mappings = self.hugetlb_extent_mappings.saturating_add(1);
            self.current_hugetlb_extents = self.current_hugetlb_extents.saturating_add(1);
            self.peak_hugetlb_extents =
                core::cmp::max(self.peak_hugetlb_extents, self.current_hugetlb_extents);
        } else if backing.is_thp_mapping() {
            self.thp_extent_mappings = self.thp_extent_mappings.saturating_add(1);
            if matches!(
                backing,
                ActualBacking::ThpCandidateNoHugepage
                    | ActualBacking::ThpCandidateNoHugepageAdviceFailed
            ) {
                self.thp_candidate_extent_mappings =
                    self.thp_candidate_extent_mappings.saturating_add(1);
            }
            self.current_thp_extents = self.current_thp_extents.saturating_add(1);
            self.peak_thp_extents = core::cmp::max(self.peak_thp_extents, self.current_thp_extents);
        } else {
            if backing == ActualBacking::HugetlbFallback {
                self.hugetlb_fallback_extent_mappings =
                    self.hugetlb_fallback_extent_mappings.saturating_add(1);
            } else {
                self.ordinary_extent_mappings = self.ordinary_extent_mappings.saturating_add(1);
            }
            self.current_ordinary_extents = self.current_ordinary_extents.saturating_add(1);
            self.peak_ordinary_extents =
                core::cmp::max(self.peak_ordinary_extents, self.current_ordinary_extents);
        }
    }

    fn note_unmapped_extent(&mut self, backing: ActualBacking) {
        self.extent_unmaps = self.extent_unmaps.saturating_add(1);
        self.current_extents = self.current_extents.saturating_sub(1);
        ACTIVE_EXTENTS.fetch_sub(1, Ordering::Release);
        if backing.is_hugetlb() {
            self.current_hugetlb_extents = self.current_hugetlb_extents.saturating_sub(1);
        } else if backing.is_thp_mapping() {
            self.current_thp_extents = self.current_thp_extents.saturating_sub(1);
            if backing.is_thp_confirmed_at_collapse() {
                self.current_thp_collapse_confirmed_extents = self
                    .current_thp_collapse_confirmed_extents
                    .saturating_sub(1);
            }
        } else {
            self.current_ordinary_extents = self.current_ordinary_extents.saturating_sub(1);
        }
        if self.current_extents == 0 {
            self.lookup = [NONE; EXTENT_LOOKUP_SLOTS];
        }
    }

    /// Promote prior-epoch THP candidates at a caller-provided quiescent phase
    /// boundary. This runs while the arena lock is held and MADV_COLLAPSE may
    /// perform synchronous kernel work, so callers must treat epoch advance as
    /// a potentially blocking control-plane operation.
    unsafe fn promote_surviving_thp_candidates(&mut self) {
        let mut idx = 0usize;
        while idx < self.next_unused_descriptor {
            match thp_promotion_eligibility(&self.extents[idx], self.current_epoch) {
                ThpPromotionEligibility::Ineligible => {
                    idx += 1;
                    continue;
                }
                ThpPromotionEligibility::LowOccupancy => {
                    self.thp_collapse_low_occupancy_skips =
                        self.thp_collapse_low_occupancy_skips.saturating_add(1);
                    idx += 1;
                    continue;
                }
                ThpPromotionEligibility::Eligible => {}
            }
            self.thp_collapse_eligible_extents =
                self.thp_collapse_eligible_extents.saturating_add(1);

            let extent_base = self.extents[idx].base;
            let extent_backing = self.extents[idx].backing;
            if matches!(
                extent_backing,
                ActualBacking::ThpCandidateNoHugepage
                    | ActualBacking::ThpCandidateNoHugepageAdviceFailed
            ) {
                self.thp_advice_attempts = self.thp_advice_attempts.saturating_add(1);
                if sys_alloc::advise_transparent_hugepage(
                    extent_base as *mut u8,
                    LIFETIME_HUGEPAGE_EXTENT_BYTES,
                ) {
                    self.thp_advice_successes = self.thp_advice_successes.saturating_add(1);
                    self.extents[idx].backing = ActualBacking::ThpAdvisedUnverified;
                } else {
                    self.thp_advice_errors = self.thp_advice_errors.saturating_add(1);
                    idx += 1;
                    continue;
                }
            }

            self.thp_collapse_attempts = self.thp_collapse_attempts.saturating_add(1);
            match sys_alloc::collapse_transparent_hugepage(
                extent_base as *mut u8,
                LIFETIME_HUGEPAGE_EXTENT_BYTES,
            ) {
                Ok(()) => {
                    self.thp_collapse_successes = self.thp_collapse_successes.saturating_add(1);
                    self.extents[idx].backing = ActualBacking::ThpCollapseSucceededPointInTime;
                    self.current_thp_collapse_confirmed_extents = self
                        .current_thp_collapse_confirmed_extents
                        .saturating_add(1);
                    self.peak_thp_collapse_confirmed_extents = core::cmp::max(
                        self.peak_thp_collapse_confirmed_extents,
                        self.current_thp_collapse_confirmed_extents,
                    );
                }
                Err(code) => {
                    self.thp_collapse_errors = self.thp_collapse_errors.saturating_add(1);
                    self.thp_collapse_last_error_code = code;
                }
            }
            idx += 1;
        }
    }

    unsafe fn create_extent(
        &mut self,
        geometry: SlotGeometry,
        class: LifetimePlacementClass,
        requested: RequestedBacking,
        backend: LifetimePageBackend,
        birth_epoch: usize,
        epoch_cohort: bool,
    ) -> Option<usize> {
        let idx = match self.allocate_descriptor() {
            Some(idx) => idx,
            None => {
                self.mapping_failures = self.mapping_failures.saturating_add(1);
                return None;
            }
        };
        let mapping = match map_extent(requested, backend) {
            Some(mapping) => mapping,
            None => {
                self.release_descriptor(idx);
                self.mapping_failures = self.mapping_failures.saturating_add(1);
                return None;
            }
        };
        if !mapping.nohugepage_advice_ok {
            self.nohugepage_advice_failures = self.nohugepage_advice_failures.saturating_add(1);
        }
        match mapping.thp_advice {
            ThpAdviceOutcome::NotAttempted => {}
            ThpAdviceOutcome::Succeeded => {
                self.thp_advice_attempts = self.thp_advice_attempts.saturating_add(1);
                self.thp_advice_successes = self.thp_advice_successes.saturating_add(1);
            }
            ThpAdviceOutcome::Failed => {
                self.thp_advice_attempts = self.thp_advice_attempts.saturating_add(1);
                self.thp_advice_errors = self.thp_advice_errors.saturating_add(1);
            }
        }
        self.extents[idx] = Extent {
            base: mapping.base as usize,
            slot_size: geometry.slot_size,
            payload_capacity: geometry.payload_capacity,
            region_capacity: geometry.region_capacity,
            live: 0,
            bucket: geometry.bucket,
            regions: [IdentityRegion::empty(); IDENTITY_REGIONS_PER_EXTENT],
            lifetime_class: class,
            cohort_epoch: if epoch_cohort { birth_epoch } else { 0 },
            backing: mapping.backing,
            adaptive_trailer: geometry.adaptive_trailer,
            available_prev: NONE,
            available_next: NONE,
            on_available_list: false,
            next_free_descriptor: NONE,
        };
        if !self.insert_lookup(idx) {
            let _ = unmap_extent(mapping.base);
            self.release_descriptor(idx);
            self.mapping_failures = self.mapping_failures.saturating_add(1);
            return None;
        }
        self.add_available(idx);
        if epoch_cohort {
            self.epoch_cohort_extent_mappings = self.epoch_cohort_extent_mappings.saturating_add(1);
        }
        self.note_mapped_extent(mapping.backing);
        Some(idx)
    }

    unsafe fn allocate_from_extent(
        &mut self,
        idx: usize,
        identity: ArenaIdentity,
        class: LifetimePlacementClass,
        birth_epoch: usize,
        require_epoch_match: bool,
        adaptive_record: Option<AdaptiveAllocationRecord>,
    ) -> *mut u8 {
        debug_assert!(self.extents[idx].has_available_slot());
        let region_idx = match self.extents[idx].matching_region_with_space(
            identity,
            birth_epoch,
            require_epoch_match,
        ) {
            Some(region_idx) => region_idx,
            None => {
                let region_idx = self.extents[idx]
                    .unassigned_region()
                    .expect("available extent has no identity region");
                self.extents[idx].regions[region_idx] = IdentityRegion {
                    identity,
                    birth_epoch,
                    epoch_mixed: false,
                    next_unused: 0,
                    live: 0,
                    free_head: NONE,
                    assigned: true,
                };
                self.identity_region_assignments =
                    self.identity_region_assignments.saturating_add(1);
                self.current_identity_regions = self.current_identity_regions.saturating_add(1);
                self.peak_identity_regions =
                    core::cmp::max(self.peak_identity_regions, self.current_identity_regions);
                region_idx
            }
        };
        if self.extents[idx].regions[region_idx].birth_epoch != birth_epoch {
            self.extents[idx].regions[region_idx].epoch_mixed = true;
        }
        let region_base = self.extents[idx].base
            + region_idx.saturating_mul(LIFETIME_HUGEPAGE_IDENTITY_REGION_BYTES);
        let slot_index = if self.extents[idx].regions[region_idx].free_head != NONE {
            let slot_index = self.extents[idx].regions[region_idx].free_head;
            let ptr = (region_base + slot_index.saturating_mul(self.extents[idx].slot_size))
                as *mut usize;
            self.extents[idx].regions[region_idx].free_head = ptr.read();
            self.slot_reuse_hits = self.slot_reuse_hits.saturating_add(1);
            slot_index
        } else {
            let slot_index = self.extents[idx].regions[region_idx].next_unused;
            self.extents[idx].regions[region_idx].next_unused += 1;
            self.slot_bump_allocations = self.slot_bump_allocations.saturating_add(1);
            slot_index
        };
        self.extents[idx].live += 1;
        self.extents[idx].regions[region_idx].live += 1;
        let slot_size = self.extents[idx].slot_size;
        if !self.extents[idx].has_available_slot() {
            self.remove_available(idx);
        }
        self.routed_allocations = self.routed_allocations.saturating_add(1);
        self.live_objects = self.live_objects.saturating_add(1);
        self.live_slot_bytes = self.live_slot_bytes.saturating_add(slot_size);
        match class {
            LifetimePlacementClass::Ephemeral => {
                self.live_ephemeral_objects = self.live_ephemeral_objects.saturating_add(1)
            }
            LifetimePlacementClass::LongLived => {
                self.live_long_lived_objects = self.live_long_lived_objects.saturating_add(1)
            }
            LifetimePlacementClass::Unknown => unreachable!(),
        }
        let ptr = (region_base + slot_index * slot_size) as *mut u8;
        if let Some(record) = adaptive_record {
            debug_assert!(self.extents[idx].adaptive_trailer);
            let trailer = AdaptiveSlotTrailer::new(
                ptr,
                record.birth_pressure,
                record.site_fingerprint,
                record.site_index,
                record.requested_size,
                record.prediction,
                record.static_hint,
            );
            ptr.add(self.extents[idx].payload_capacity)
                .cast::<AdaptiveSlotTrailer>()
                .write(trailer);
        }
        ptr
    }

    #[inline]
    fn note_runtime_validation(
        &mut self,
        class: LifetimePlacementClass,
        actual_backing: ActualBacking,
        identity: ArenaIdentity,
        birth_epoch: usize,
        epoch_mixed: bool,
        bytes: usize,
    ) {
        if identity.flags & FLAG_DELAYED_FREE != 0 {
            self.runtime_validation_excluded_objects =
                self.runtime_validation_excluded_objects.saturating_add(1);
            self.runtime_validation_excluded_bytes =
                self.runtime_validation_excluded_bytes.saturating_add(bytes);
            self.runtime_delayed_free_excluded_objects =
                self.runtime_delayed_free_excluded_objects.saturating_add(1);
            self.runtime_delayed_free_excluded_bytes = self
                .runtime_delayed_free_excluded_bytes
                .saturating_add(bytes);
            return;
        }
        if epoch_mixed {
            self.runtime_validation_excluded_objects =
                self.runtime_validation_excluded_objects.saturating_add(1);
            self.runtime_validation_excluded_bytes =
                self.runtime_validation_excluded_bytes.saturating_add(bytes);
            self.runtime_mixed_epoch_excluded_objects =
                self.runtime_mixed_epoch_excluded_objects.saturating_add(1);
            self.runtime_mixed_epoch_excluded_bytes = self
                .runtime_mixed_epoch_excluded_bytes
                .saturating_add(bytes);
            return;
        }
        let actual_long = self.current_epoch != birth_epoch;
        self.runtime_validated_objects = self.runtime_validated_objects.saturating_add(1);
        self.runtime_validated_bytes = self.runtime_validated_bytes.saturating_add(bytes);
        self.predictor_confusion.record(
            class == LifetimePlacementClass::LongLived,
            actual_long,
            bytes,
        );
        self.placement_confusion.record(
            actual_backing.is_large_page_confirmed(),
            actual_long,
            bytes,
        );
    }

    unsafe fn deallocate(&mut self, ptr: *mut u8) -> bool {
        let base = (ptr as usize) & !(LIFETIME_HUGEPAGE_EXTENT_BYTES - 1);
        let idx = match self.lookup_extent(base) {
            Some(idx) => idx,
            None => return false,
        };
        let extent_base = self.extents[idx].base;
        let extent_backing = self.extents[idx].backing;
        let lifetime_class = self.extents[idx].lifetime_class;
        let cohort_epoch = self.extents[idx].cohort_epoch;
        let slot_size = self.extents[idx].slot_size;
        let payload_capacity = self.extents[idx].payload_capacity;
        let adaptive_trailer = self.extents[idx].adaptive_trailer;
        let offset = (ptr as usize).saturating_sub(extent_base);
        if offset >= LIFETIME_HUGEPAGE_EXTENT_BYTES || self.extents[idx].live == 0 {
            panic!("invalid lifetime-arena pointer release");
        }
        let region_idx = offset / LIFETIME_HUGEPAGE_IDENTITY_REGION_BYTES;
        let region_offset = offset % LIFETIME_HUGEPAGE_IDENTITY_REGION_BYTES;
        let region = self.extents[idx].regions[region_idx];
        if !region.assigned
            || region_offset % slot_size != 0
            || region_offset / slot_size >= region.next_unused
            || region.live == 0
        {
            panic!("invalid lifetime-arena identity-region pointer release");
        }
        if adaptive_trailer {
            let trailer = ptr
                .add(payload_capacity)
                .cast::<AdaptiveSlotTrailer>()
                .read();
            self.adaptive_note_deallocation(
                ptr,
                payload_capacity,
                slot_size,
                extent_backing,
                trailer,
            );
        } else {
            self.note_runtime_validation(
                lifetime_class,
                extent_backing,
                region.identity,
                region.birth_epoch,
                region.epoch_mixed,
                slot_size,
            );
        }
        let was_full = !self.extents[idx].has_available_slot();
        let slot_index = region_offset / slot_size;
        (ptr as *mut usize).write(region.free_head);
        self.extents[idx].regions[region_idx].free_head = slot_index;
        self.extents[idx].regions[region_idx].live -= 1;
        self.extents[idx].live -= 1;
        if self.extents[idx].regions[region_idx].live == 0 {
            self.extents[idx].regions[region_idx] = IdentityRegion::empty();
            self.identity_region_releases = self.identity_region_releases.saturating_add(1);
            self.current_identity_regions = self.current_identity_regions.saturating_sub(1);
        }
        let extent_accepts_current_epoch = lifetime_hugepage_policy()
            != LifetimeHugepagePolicy::EpochCohortHugepage
            || cohort_epoch == self.current_epoch;
        if was_full && extent_accepts_current_epoch {
            self.add_available(idx);
        }
        self.routed_deallocations = self.routed_deallocations.saturating_add(1);
        self.live_objects = self.live_objects.saturating_sub(1);
        self.live_slot_bytes = self.live_slot_bytes.saturating_sub(slot_size);
        match lifetime_class {
            LifetimePlacementClass::Ephemeral => {
                self.live_ephemeral_objects = self.live_ephemeral_objects.saturating_sub(1)
            }
            LifetimePlacementClass::LongLived => {
                self.live_long_lived_objects = self.live_long_lived_objects.saturating_sub(1)
            }
            LifetimePlacementClass::Unknown => unreachable!(),
        }
        if self.extents[idx].live != 0 {
            return true;
        }

        self.remove_available(idx);
        if unmap_extent(extent_base as *mut u8) {
            if !self.remove_lookup(idx) {
                panic!("lifetime-arena extent index disappeared before unmap");
            }
            self.note_unmapped_extent(extent_backing);
            self.release_descriptor(idx);
        } else {
            // Preserve provenance and reuse capability if the kernel refused
            // the terminal release.
            self.extent_unmap_failures = self.extent_unmap_failures.saturating_add(1);
            if extent_accepts_current_epoch {
                self.add_available(idx);
            }
        }
        true
    }
}

static POLICY: AtomicUsize = AtomicUsize::new(LifetimeHugepagePolicy::Disabled as usize);
static BACKEND: AtomicUsize = AtomicUsize::new(LifetimePageBackend::ExplicitHugeTLB as usize);
static ACTIVE_EXTENTS: AtomicUsize = AtomicUsize::new(0);
static ARENA: Mutex<LifetimeArenaState> = Mutex::new(LifetimeArenaState::new());
#[thread_local]
static mut PHASE_FLUSH_ACTIVE: bool = false;

struct PhaseFlushGuard;

impl PhaseFlushGuard {
    #[inline]
    unsafe fn enter() -> Option<Self> {
        if PHASE_FLUSH_ACTIVE {
            return None;
        }
        PHASE_FLUSH_ACTIVE = true;
        Some(Self)
    }
}

impl Drop for PhaseFlushGuard {
    fn drop(&mut self) {
        unsafe { PHASE_FLUSH_ACTIVE = false };
    }
}

#[inline]
fn lifetime_class_index(class: LifetimePlacementClass) -> Option<usize> {
    match class {
        LifetimePlacementClass::Ephemeral => Some(0),
        LifetimePlacementClass::LongLived => Some(1),
        LifetimePlacementClass::Unknown => None,
    }
}

#[inline]
fn checked_align_up(value: usize, align: usize) -> Option<usize> {
    value
        .checked_add(align - 1)
        .map(|rounded| rounded & !(align - 1))
}

fn slot_geometry(
    layout: Layout,
    class: LifetimePlacementClass,
    adaptive_trailer: bool,
) -> Option<SlotGeometry> {
    if layout.size() == 0 || layout.align() > MAX_SLOT_ALIGN {
        return None;
    }
    let requested = core::cmp::max(layout.size(), size_of::<usize>());
    let (size_class, rounded_size) = get_size_class_tuple(requested);
    let size_class_idx = match size_class {
        SizeClass::Base(idx) => idx,
        SizeClass::Large(_) => return None,
    };
    let (payload_capacity, slot_size) = if adaptive_trailer {
        let payload_capacity =
            checked_align_up(rounded_size, core::mem::align_of::<AdaptiveSlotTrailer>())?;
        let stride_align =
            core::cmp::max(layout.align(), core::mem::align_of::<AdaptiveSlotTrailer>());
        let slot_size = payload_capacity
            .checked_add(size_of::<AdaptiveSlotTrailer>())
            .and_then(|bytes| checked_align_up(bytes, stride_align))?;
        (payload_capacity, slot_size)
    } else {
        let slot_size = checked_align_up(rounded_size, layout.align())?;
        (slot_size, slot_size)
    };
    if slot_size == 0 || slot_size > MAX_SLOT_BYTES {
        return None;
    }
    let region_capacity = LIFETIME_HUGEPAGE_IDENTITY_REGION_BYTES / slot_size;
    if region_capacity == 0 {
        return None;
    }
    let align_class = layout.align().trailing_zeros() as usize;
    if align_class >= ALIGN_CLASS_COUNT {
        return None;
    }
    let lifetime_idx = lifetime_class_index(class)?;
    let bucket =
        (lifetime_idx * TOTAL_SIZE_CLASS + size_class_idx) * ALIGN_CLASS_COUNT + align_class;
    Some(SlotGeometry {
        slot_size,
        payload_capacity,
        region_capacity,
        bucket,
        adaptive_trailer,
    })
}

unsafe fn map_extent(
    requested: RequestedBacking,
    backend: LifetimePageBackend,
) -> Option<ExtentMapping> {
    let layout = Layout::from_size_align(
        LIFETIME_HUGEPAGE_EXTENT_BYTES,
        LIFETIME_HUGEPAGE_EXTENT_BYTES,
    )
    .ok()?;
    match requested {
        RequestedBacking::Ordinary => {
            let ptr = sys_alloc::mmap_over_page_aligned(layout, prots::PROT_READ_WRITE);
            if ptr.is_null() || ptr as usize % LIFETIME_HUGEPAGE_EXTENT_BYTES != 0 {
                if !ptr.is_null() {
                    sys_alloc::munmap(ptr, LIFETIME_HUGEPAGE_EXTENT_BYTES);
                }
                return None;
            }
            Some(ExtentMapping {
                base: ptr,
                backing: ActualBacking::Ordinary,
                nohugepage_advice_ok: advise_no_hugepage(ptr),
                thp_advice: ThpAdviceOutcome::NotAttempted,
            })
        }
        RequestedBacking::EpochCandidate => {
            if backend != LifetimePageBackend::TransparentHugepage || !cfg!(target_os = "linux") {
                return None;
            }
            let ptr = sys_alloc::mmap_over_page_aligned(layout, prots::PROT_READ_WRITE);
            if ptr.is_null() || ptr as usize % LIFETIME_HUGEPAGE_EXTENT_BYTES != 0 {
                if !ptr.is_null() {
                    sys_alloc::munmap(ptr, LIFETIME_HUGEPAGE_EXTENT_BYTES);
                }
                return None;
            }
            let nohugepage_advice_ok = advise_no_hugepage(ptr);
            Some(ExtentMapping {
                base: ptr,
                backing: if nohugepage_advice_ok {
                    ActualBacking::ThpCandidateNoHugepage
                } else {
                    ActualBacking::ThpCandidateNoHugepageAdviceFailed
                },
                nohugepage_advice_ok,
                thp_advice: ThpAdviceOutcome::NotAttempted,
            })
        }
        RequestedBacking::LargePage => match backend {
            LifetimePageBackend::ExplicitHugeTLB => {
                let mapped = sys_alloc::mmap_huge_with_backing(
                    LIFETIME_HUGEPAGE_EXTENT_BYTES,
                    prots::PROT_READ_WRITE,
                );
                if !mapped.is_success() || mapped.ptr as usize % LIFETIME_HUGEPAGE_EXTENT_BYTES != 0
                {
                    if mapped.is_success() {
                        sys_alloc::munmap(mapped.ptr, LIFETIME_HUGEPAGE_EXTENT_BYTES);
                    }
                    return None;
                }
                let backing = if mapped.backing == HugePageMmapBacking::HugePage {
                    ActualBacking::Hugetlb
                } else {
                    ActualBacking::HugetlbFallback
                };
                Some(ExtentMapping {
                    base: mapped.ptr,
                    backing,
                    nohugepage_advice_ok: true,
                    thp_advice: ThpAdviceOutcome::NotAttempted,
                })
            }
            LifetimePageBackend::TransparentHugepage => {
                let mapped = sys_alloc::mmap_transparent_hugepage(
                    LIFETIME_HUGEPAGE_EXTENT_BYTES,
                    prots::PROT_READ_WRITE,
                );
                if !mapped.is_success() || mapped.ptr as usize % LIFETIME_HUGEPAGE_EXTENT_BYTES != 0
                {
                    if mapped.is_success() {
                        sys_alloc::munmap(mapped.ptr, LIFETIME_HUGEPAGE_EXTENT_BYTES);
                    }
                    return None;
                }
                Some(ExtentMapping {
                    base: mapped.ptr,
                    backing: if mapped.advice_succeeded {
                        ActualBacking::ThpAdvisedUnverified
                    } else {
                        ActualBacking::ThpAdviceFailed
                    },
                    nohugepage_advice_ok: true,
                    thp_advice: if mapped.advice_succeeded {
                        ThpAdviceOutcome::Succeeded
                    } else {
                        ThpAdviceOutcome::Failed
                    },
                })
            }
        },
    }
}

#[cfg(target_os = "linux")]
unsafe fn advise_no_hugepage(ptr: *mut u8) -> bool {
    libc::madvise(
        ptr as *mut libc::c_void,
        LIFETIME_HUGEPAGE_EXTENT_BYTES,
        libc::MADV_NOHUGEPAGE,
    ) == 0
}

#[cfg(not(target_os = "linux"))]
unsafe fn advise_no_hugepage(_ptr: *mut u8) -> bool {
    true
}

#[cfg(unix)]
unsafe fn unmap_extent(ptr: *mut u8) -> bool {
    libc::munmap(ptr as *mut libc::c_void, LIFETIME_HUGEPAGE_EXTENT_BYTES) == 0
}

#[cfg(not(unix))]
unsafe fn unmap_extent(ptr: *mut u8) -> bool {
    sys_alloc::munmap(ptr, LIFETIME_HUGEPAGE_EXTENT_BYTES);
    true
}

pub fn lifetime_hugepage_policy() -> LifetimeHugepagePolicy {
    LifetimeHugepagePolicy::from_usize(POLICY.load(Ordering::Acquire))
}

pub fn lifetime_hugepage_backend() -> LifetimePageBackend {
    LifetimePageBackend::from_usize(BACKEND.load(Ordering::Acquire))
}

/// Select the placement policy before the process creates routed objects.
/// Changing policy while arena mappings remain live is rejected.
pub fn lifetime_hugepage_configure(policy: LifetimeHugepagePolicy) -> bool {
    let backend = if policy == LifetimeHugepagePolicy::AdaptiveRuntimeHugepage {
        LifetimePageBackend::TransparentHugepage
    } else {
        LifetimePageBackend::ExplicitHugeTLB
    };
    lifetime_hugepage_configure_with_backend(policy, backend)
}

/// Select placement policy and physical page backend as orthogonal controls.
/// Changing either control while arena mappings remain live is rejected.
pub fn lifetime_hugepage_configure_with_backend(
    policy: LifetimeHugepagePolicy,
    backend: LifetimePageBackend,
) -> bool {
    if policy == LifetimeHugepagePolicy::AdaptiveRuntimeHugepage
        && backend != LifetimePageBackend::TransparentHugepage
    {
        return false;
    }
    let state = ARENA.lock();
    if state.live_objects != 0 || state.current_extents != 0 {
        return false;
    }
    BACKEND.store(backend as usize, Ordering::Release);
    POLICY.store(policy as usize, Ordering::Release);
    true
}

pub fn lifetime_hugepage_stats_snapshot() -> LifetimeHugepageStatsSnapshot {
    ARENA.lock().snapshot()
}

/// Advance the process-wide logical phase used by runtime lifetime validation.
/// The caller is responsible for placing a workload barrier around the phase
/// boundary. Advancing never frees storage or invalidates live pointers.
#[inline(never)]
pub fn lifetime_hugepage_advance_epoch() -> usize {
    let mut state = ARENA.lock();
    if lifetime_hugepage_policy() == LifetimeHugepagePolicy::Disabled {
        return state.current_epoch;
    }
    state.current_epoch = state.current_epoch.wrapping_add(1);
    if state.current_epoch == 0 {
        state.current_epoch = 1;
    }
    state.phase_advances = state.phase_advances.saturating_add(1);
    if lifetime_hugepage_policy() == LifetimeHugepagePolicy::EpochCohortHugepage {
        state.detach_available_epoch_cohorts();
        if lifetime_hugepage_backend() == LifetimePageBackend::TransparentHugepage {
            // The caller-provided phase barrier makes this synchronous kernel
            // promotion safe with respect to allocator payload access.
            unsafe { state.promote_surviving_thp_candidates() };
        }
    }
    state.current_epoch
}

/// End a lifetime phase on the current thread by terminally releasing its
/// retained semantic cache and delayed-free entries. This makes phase
/// boundaries actionable for extent reclamation instead of waiting for TLS
/// teardown. A same-thread reentrant call is conservatively ignored.
pub fn lifetime_hugepage_phase_flush_current_thread() -> usize {
    unsafe {
        let Some(_guard) = PhaseFlushGuard::enter() else {
            return 0;
        };
        super::type_isolation::drain_current_thread_semantic_retained_state(
            &crate::cache::RustAllocator::new(),
        )
    }
}

/// Reset diagnostics only after every arena-owned mapping has been released.
/// An active adaptive policy preserves learned site states while starting a
/// fresh pressure/telemetry window. Configure `Disabled` before reset when an
/// experiment explicitly needs to discard the learned classifier model.
pub fn lifetime_hugepage_stats_reset() -> bool {
    let mut state = ARENA.lock();
    if state.live_objects != 0 || state.current_extents != 0 {
        return false;
    }
    let preserve_adaptive_model =
        lifetime_hugepage_policy() == LifetimeHugepagePolicy::AdaptiveRuntimeHugepage;
    state.reset_counters(preserve_adaptive_model);
    true
}

/// Try to route one exact semantic allocation into a lifetime/size arena.
/// `None` preserves the existing allocator path.
pub(crate) unsafe fn try_allocate(layout: Layout, metadata: AllocationMetadata) -> Option<*mut u8> {
    if POLICY.load(Ordering::Acquire) == LifetimeHugepagePolicy::Disabled as usize {
        return None;
    }
    let static_class = lifetime_placement_class(metadata.lifetime_hint);
    let mut state = ARENA.lock();
    let policy = lifetime_hugepage_policy();
    let backend = lifetime_hugepage_backend();
    let adaptive = policy == LifetimeHugepagePolicy::AdaptiveRuntimeHugepage;
    let (class, geometry, adaptive_site) = if adaptive {
        let cold_geometry = match slot_geometry(layout, LifetimePlacementClass::Ephemeral, true) {
            Some(geometry) => geometry,
            None => {
                state.unsupported_layout_bypasses =
                    state.unsupported_layout_bypasses.saturating_add(1);
                return None;
            }
        };
        let key = match AdaptiveSiteKey::from_metadata(
            metadata,
            cold_geometry.payload_capacity,
            layout.align(),
        ) {
            Some(key) => key,
            None => {
                state.adaptive_missing_identity_bypasses =
                    state.adaptive_missing_identity_bypasses.saturating_add(1);
                return None;
            }
        };
        let site_idx = state.adaptive_site_slot(key, static_class)?;
        let prediction = state.adaptive_sites[site_idx].effective_prediction();
        if !state.adaptive_sites[site_idx].should_track_allocation() {
            state.adaptive_note_bypass(cold_geometry.payload_capacity, prediction);
            return None;
        }
        let class = prediction.placement_class();
        let geometry = if class == LifetimePlacementClass::Ephemeral {
            cold_geometry
        } else {
            slot_geometry(layout, class, true).expect("adaptive geometry changed across class")
        };
        (class, geometry, Some((site_idx, prediction)))
    } else {
        if static_class == LifetimePlacementClass::Unknown {
            state.unknown_bypasses = state.unknown_bypasses.saturating_add(1);
            state.unknown_bypass_requested_bytes = state
                .unknown_bypass_requested_bytes
                .saturating_add(layout.size());
            return None;
        }
        let geometry = match slot_geometry(layout, static_class, false) {
            Some(geometry) => geometry,
            None => {
                if static_class != LifetimePlacementClass::Unknown {
                    state.unsupported_layout_bypasses =
                        state.unsupported_layout_bypasses.saturating_add(1);
                }
                return None;
            }
        };
        (static_class, geometry, None)
    };
    let requested_backing = match policy.requested_backing(class, backend) {
        Some(backing) => backing,
        None => {
            if class == LifetimePlacementClass::Unknown {
                state.unknown_bypasses = state.unknown_bypasses.saturating_add(1);
                state.unknown_bypass_requested_bytes = state
                    .unknown_bypass_requested_bytes
                    .saturating_add(layout.size());
            }
            return None;
        }
    };
    let identity = ArenaIdentity::from_metadata(metadata);
    let birth_epoch = state.current_epoch;
    let epoch_cohort = policy.separates_epoch_extents();
    let idx = if let Some(idx) =
        state.find_available(geometry.bucket, identity, birth_epoch, epoch_cohort)
    {
        idx
    } else {
        match state.create_extent(
            geometry,
            class,
            requested_backing,
            backend,
            birth_epoch,
            epoch_cohort,
        ) {
            Some(idx) => idx,
            None => {
                state.allocation_fallbacks = state.allocation_fallbacks.saturating_add(1);
                return None;
            }
        }
    };
    let adaptive_record = adaptive_site.map(|(site_idx, prediction)| {
        let birth_pressure =
            state.adaptive_note_allocation(site_idx, geometry.payload_capacity, prediction);
        AdaptiveAllocationRecord {
            birth_pressure,
            site_fingerprint: state.adaptive_sites[site_idx].fingerprint,
            site_index: site_idx,
            requested_size: layout.size(),
            prediction,
            static_hint: static_class,
        }
    });
    Some(state.allocate_from_extent(
        idx,
        identity,
        class,
        birth_epoch,
        epoch_cohort,
        adaptive_record,
    ))
}

#[inline]
pub(crate) fn owns(ptr: *mut u8) -> bool {
    if ptr.is_null() || ACTIVE_EXTENTS.load(Ordering::Acquire) == 0 {
        return false;
    }
    let base = (ptr as usize) & !(LIFETIME_HUGEPAGE_EXTENT_BYTES - 1);
    ARENA.lock().lookup_extent(base).is_some()
}

/// Return `None` for ordinary pointers and `Some(fits)` for arena pointers.
pub(crate) fn realloc_in_place_supported(ptr: *mut u8, new_layout: Layout) -> Option<bool> {
    if ptr.is_null() || ACTIVE_EXTENTS.load(Ordering::Acquire) == 0 {
        return None;
    }
    let base = (ptr as usize) & !(LIFETIME_HUGEPAGE_EXTENT_BYTES - 1);
    let state = ARENA.lock();
    let idx = state.lookup_extent(base)?;
    let extent = &state.extents[idx];
    let offset = (ptr as usize).saturating_sub(extent.base);
    let region_idx = offset / LIFETIME_HUGEPAGE_IDENTITY_REGION_BYTES;
    let region_offset = offset % LIFETIME_HUGEPAGE_IDENTITY_REGION_BYTES;
    let region = extent.regions.get(region_idx)?;
    Some(
        offset < LIFETIME_HUGEPAGE_EXTENT_BYTES
            && region.assigned
            && region_offset % extent.slot_size == 0
            && region_offset / extent.slot_size < region.next_unused
            && new_layout.size() <= extent.payload_capacity
            && (ptr as usize) % new_layout.align() == 0,
    )
}

/// Release an arena pointer. False means the ordinary backend owns it.
pub(crate) unsafe fn try_deallocate(ptr: *mut u8) -> bool {
    if ptr.is_null() || ACTIVE_EXTENTS.load(Ordering::Acquire) == 0 {
        return false;
    }
    ARENA.lock().deallocate(ptr)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn page_backend_changes_backing_without_changing_lifetime_selection() {
        assert_eq!(
            LifetimeHugepagePolicy::LongLivedHugepage.requested_backing(
                LifetimePlacementClass::Ephemeral,
                LifetimePageBackend::ExplicitHugeTLB,
            ),
            Some(RequestedBacking::Ordinary)
        );
        assert_eq!(
            LifetimeHugepagePolicy::LongLivedHugepage.requested_backing(
                LifetimePlacementClass::LongLived,
                LifetimePageBackend::ExplicitHugeTLB,
            ),
            Some(RequestedBacking::LargePage)
        );
        assert_eq!(
            LifetimeHugepagePolicy::LongLivedHugepage.requested_backing(
                LifetimePlacementClass::LongLived,
                LifetimePageBackend::TransparentHugepage,
            ),
            Some(RequestedBacking::LargePage)
        );
    }

    #[test]
    fn epoch_thp_delays_only_selected_largepage_placements() {
        assert_eq!(
            LifetimeHugepagePolicy::EpochCohortHugepage.requested_backing(
                LifetimePlacementClass::LongLived,
                LifetimePageBackend::TransparentHugepage,
            ),
            Some(RequestedBacking::EpochCandidate)
        );
        assert_eq!(
            LifetimeHugepagePolicy::EpochCohortHugepage.requested_backing(
                LifetimePlacementClass::Ephemeral,
                LifetimePageBackend::TransparentHugepage,
            ),
            Some(RequestedBacking::Ordinary)
        );
        assert_eq!(
            LifetimeHugepagePolicy::EpochCohortHugepage.requested_backing(
                LifetimePlacementClass::LongLived,
                LifetimePageBackend::ExplicitHugeTLB,
            ),
            Some(RequestedBacking::LargePage)
        );
    }

    #[test]
    fn advice_only_backing_never_counts_as_confirmed_largepage() {
        assert!(!ActualBacking::ThpAdvisedUnverified.is_large_page_confirmed());
        assert!(!ActualBacking::ThpAdviceFailed.is_large_page_confirmed());
        assert!(ActualBacking::ThpCollapseSucceededPointInTime.is_large_page_confirmed());
        assert!(ActualBacking::Hugetlb.is_large_page_confirmed());
    }

    #[test]
    fn epoch_promotion_skips_candidates_below_preregistered_density() {
        let extent = Extent {
            base: LIFETIME_HUGEPAGE_EXTENT_BYTES,
            slot_size: size_of::<usize>(),
            payload_capacity: size_of::<usize>(),
            region_capacity: LIFETIME_HUGEPAGE_IDENTITY_REGION_BYTES / size_of::<usize>(),
            live: 1,
            bucket: 0,
            regions: [IdentityRegion::empty(); IDENTITY_REGIONS_PER_EXTENT],
            lifetime_class: LifetimePlacementClass::LongLived,
            cohort_epoch: 1,
            backing: ActualBacking::ThpCandidateNoHugepage,
            adaptive_trailer: false,
            available_prev: NONE,
            available_next: NONE,
            on_available_list: false,
            next_free_descriptor: NONE,
        };

        assert_eq!(
            thp_promotion_eligibility(&extent, 2),
            ThpPromotionEligibility::LowOccupancy
        );

        let mut dense_survivor = extent;
        dense_survivor.live = THP_PROMOTION_MIN_LIVE_BYTES / dense_survivor.slot_size;
        assert_eq!(
            thp_promotion_eligibility(&dense_survivor, 2),
            ThpPromotionEligibility::Eligible
        );
        dense_survivor.cohort_epoch = 2;
        assert_eq!(
            thp_promotion_eligibility(&dense_survivor, 2),
            ThpPromotionEligibility::Ineligible
        );
    }

    fn adaptive_test_key(callsite: u64, type_id: u64) -> AdaptiveSiteKey {
        AdaptiveSiteKey {
            callsite,
            type_id,
            module_id: 7,
            flags: 1,
            placement_hint: 0,
            payload_capacity: 64,
            align: 8,
        }
    }

    #[test]
    fn adaptive_policy_maps_cold_short_ordinary_and_long_thp() {
        assert_eq!(
            LifetimeHugepagePolicy::AdaptiveRuntimeHugepage.requested_backing(
                AdaptivePrediction::Cold.placement_class(),
                LifetimePageBackend::TransparentHugepage,
            ),
            Some(RequestedBacking::Ordinary)
        );
        assert_eq!(
            LifetimeHugepagePolicy::AdaptiveRuntimeHugepage.requested_backing(
                AdaptivePrediction::Short.placement_class(),
                LifetimePageBackend::TransparentHugepage,
            ),
            Some(RequestedBacking::Ordinary)
        );
        assert_eq!(
            LifetimeHugepagePolicy::AdaptiveRuntimeHugepage.requested_backing(
                AdaptivePrediction::Long.placement_class(),
                LifetimePageBackend::TransparentHugepage,
            ),
            Some(RequestedBacking::LargePage)
        );
    }

    #[test]
    fn adaptive_age_thresholds_are_exact_and_marker_free() {
        assert_eq!(adaptive_lifetime_outcome(0), Some(false));
        assert_eq!(
            adaptive_lifetime_outcome(ADAPTIVE_EPOCH_BYTES - 1),
            Some(false)
        );
        assert_eq!(adaptive_lifetime_outcome(ADAPTIVE_EPOCH_BYTES), None);
        assert_eq!(adaptive_lifetime_outcome(ADAPTIVE_LONG_AGE_BYTES - 1), None);
        assert_eq!(
            adaptive_lifetime_outcome(ADAPTIVE_LONG_AGE_BYTES),
            Some(true)
        );
    }

    #[test]
    fn adaptive_site_requires_runtime_evidence_and_learns_both_classes() {
        let key = adaptive_test_key(11, 21);
        let mut long = AdaptiveSiteState::new(key, LifetimePlacementClass::Unknown);
        for _ in 0..(ADAPTIVE_MIN_DECISIVE_SAMPLES - 1) {
            assert_eq!(long.observe(Some(true)), AdaptiveTransition::None);
            assert_eq!(long.prediction, AdaptivePrediction::Cold);
        }
        assert_eq!(long.observe(Some(true)), AdaptiveTransition::PromotedLong);
        assert_eq!(long.prediction, AdaptivePrediction::Long);

        let mut short = AdaptiveSiteState::new(key, LifetimePlacementClass::Unknown);
        for _ in 0..(ADAPTIVE_MIN_DECISIVE_SAMPLES - 1) {
            assert_eq!(short.observe(Some(false)), AdaptiveTransition::None);
        }
        assert_eq!(
            short.observe(Some(false)),
            AdaptiveTransition::PromotedShort
        );
        assert_eq!(short.prediction, AdaptivePrediction::Short);
    }

    #[test]
    fn adaptive_censored_samples_do_not_vote_and_hysteresis_delays_demotion() {
        let mut site =
            AdaptiveSiteState::new(adaptive_test_key(12, 22), LifetimePlacementClass::Unknown);
        for _ in 0..32 {
            assert_eq!(site.observe(None), AdaptiveTransition::None);
        }
        assert_eq!(site.decisive_samples, 0);
        assert_eq!(site.censored_samples, 32);
        for _ in 0..ADAPTIVE_MIN_DECISIVE_SAMPLES {
            let _ = site.observe(Some(true));
        }
        assert_eq!(site.prediction, AdaptivePrediction::Long);
        for _ in 0..5 {
            assert_eq!(site.observe(Some(false)), AdaptiveTransition::None);
            assert_eq!(site.prediction, AdaptivePrediction::Long);
        }
        assert_eq!(site.observe(Some(false)), AdaptiveTransition::Demoted);
        assert_eq!(site.prediction, AdaptivePrediction::Cold);
    }

    #[test]
    fn adaptive_runtime_corrects_a_wrong_static_prior() {
        let mut site =
            AdaptiveSiteState::new(adaptive_test_key(13, 23), LifetimePlacementClass::LongLived);
        for _ in 0..10 {
            assert_eq!(site.observe(Some(false)), AdaptiveTransition::None);
        }
        assert_eq!(site.observe(Some(false)), AdaptiveTransition::PromotedShort);
        assert_eq!(site.prediction, AdaptivePrediction::Short);
        assert_eq!(site.static_prior, LifetimePlacementClass::LongLived);
    }

    #[test]
    fn adaptive_conflicting_priors_are_neutralized_before_runtime_learning() {
        let mut site =
            AdaptiveSiteState::new(adaptive_test_key(14, 24), LifetimePlacementClass::LongLived);
        assert!(site.note_prior(LifetimePlacementClass::Ephemeral));
        assert!(site.prior_conflict);
        assert_eq!(site.static_prior, LifetimePlacementClass::Unknown);
        assert_eq!((site.short_votes, site.long_votes), (1, 1));
        assert_eq!(site.effective_prediction(), AdaptivePrediction::Cold);

        // Once compiler priors disagree, later hints stay advisory-only and
        // eight fresh decisive runtime outcomes retain final authority.
        assert!(!site.note_prior(LifetimePlacementClass::LongLived));
        for _ in 0..(ADAPTIVE_MIN_DECISIVE_SAMPLES - 1) {
            assert_eq!(site.observe(Some(true)), AdaptiveTransition::None);
        }
        assert_eq!(site.observe(Some(true)), AdaptiveTransition::PromotedLong);
        assert_eq!(site.effective_prediction(), AdaptivePrediction::Long);
    }

    #[test]
    fn adaptive_late_concrete_prior_contributes_weak_votes_once() {
        let mut site =
            AdaptiveSiteState::new(adaptive_test_key(15, 25), LifetimePlacementClass::Unknown);
        let _ = site.observe(Some(false));
        assert_eq!((site.short_votes, site.long_votes), (2, 1));

        assert!(!site.note_prior(LifetimePlacementClass::LongLived));
        assert_eq!(site.static_prior, LifetimePlacementClass::LongLived);
        assert_eq!((site.short_votes, site.long_votes), (2, 3));
        assert!(!site.note_prior(LifetimePlacementClass::LongLived));
        assert_eq!((site.short_votes, site.long_votes), (2, 3));
    }

    #[test]
    fn adaptive_geometry_keeps_trailer_outside_payload_and_checksums_identity() {
        let layout = Layout::from_size_align(4096, 64).unwrap();
        let geometry = slot_geometry(layout, LifetimePlacementClass::Ephemeral, true).unwrap();
        assert_eq!(geometry.payload_capacity, 4096);
        assert!(geometry.slot_size >= geometry.payload_capacity + size_of::<AdaptiveSlotTrailer>());
        assert_eq!(geometry.slot_size % layout.align(), 0);

        let mut storage = [0u8; 8192];
        let ptr = storage.as_mut_ptr();
        let trailer = AdaptiveSlotTrailer::new(
            ptr,
            99,
            101,
            3,
            layout.size(),
            AdaptivePrediction::Long,
            LifetimePlacementClass::Ephemeral,
        );
        assert!(trailer.is_valid(ptr, geometry.payload_capacity));
        assert!(!trailer.is_valid(unsafe { ptr.add(1) }, geometry.payload_capacity));
    }

    #[test]
    fn adaptive_site_key_uses_full_allocation_identity() {
        let first = adaptive_test_key(17, 27);
        let mut second = first;
        second.type_id += 1;
        assert_ne!(first, second);
        second = first;
        second.payload_capacity *= 2;
        assert_ne!(first, second);
        second = first;
        second.align *= 2;
        assert_ne!(first, second);
    }
}
